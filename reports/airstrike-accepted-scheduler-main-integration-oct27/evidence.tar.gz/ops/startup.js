'use strict';
const fs = require('node:fs'), crypto = require('node:crypto'), assert = require('node:assert/strict');
const limits = fs.readFileSync('/proc/self/limits','utf8');
for (const name of ['Max data size','Max address space']) {
 const line=limits.split('\n').find(l=>l.startsWith(name));
 assert(/unlimited\s+unlimited/.test(line),line);
}
const identity={ executable:process.execPath, executableSHA256:crypto.createHash('sha256').update(fs.readFileSync(process.execPath)).digest('hex'), version:process.version, flags:process.execArgv, cwd:process.cwd(), environment:process.env, inheritedLimits:limits, startup:'PASS', physicalAggregateRSSLimit:768*1024**2, heapFlagIsNotProcessCap:true };
console.log(JSON.stringify(identity,null,2));
