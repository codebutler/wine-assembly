import pathlib,subprocess,resource,fcntl,json,hashlib,os
O=pathlib.Path(__file__).parent; R=O.parent/'repo'
C='3a2cae66a6a32b3cebe05880564815062873b390'; A='a217f896b5252a4eaaaaad2a2057ffcf76f92ce9'; M='3afff4f4e7fd50ee8ba25e01b01bd3c6c4b11af3'
D=pathlib.Path('/tmp/airstrike-scheduler-decision-observer-oct27/repo'); AD=pathlib.Path('/tmp/airstrike-scheduler-observer-independent-accept-oct27/repo'); B=pathlib.Path('/tmp/generally-current-boundary-accept-integrate-oct27/repo')
def git(repo,*args):
 def lim(): resource.setrlimit(resource.RLIMIT_DATA,(512*1024**2,512*1024**2))
 with open('/tmp/wine-ops-production-git.lock','a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  p=subprocess.run(['git','-C',str(repo),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,preexec_fn=lim)
 if p.returncode: raise RuntimeError((args,p.returncode,p.stderr.decode()[:1000]))
 assert len(p.stdout)+len(p.stderr)<2*1024**2
 return p.stdout
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,x): (O/n).write_text(json.dumps(x,indent=2)+'\n')
sources={D.parent/'ops/receipt-manifest.json':'66a7737a8e17027bf0ae193b75b23a3cd88efebd8cc3aed6454f67ce1a602da9',AD.parent/'ops/receipt-manifest.json':'0d4d75f4758f6ac884355723ecac8a6eaa7b52d354696a805154038cb7835a67'}
for p,h in sources.items():assert sha(p.read_bytes())==h
assert (O/'remote-initial.stdout').read_text().split()==[M,'refs/heads/main']
save('launch-configuration.json',dict(ssh=os.environ['GIT_SSH_COMMAND'],mountArgv=[],intendedMountFiles=[],mountParser='not applicable: no filename-bearing mount argv or runtime invocation',fetchBytes=0,canonicalReceipts=[dict(path=str(p),sha256=h) for p,h in sources.items()]))
candidate=['docs/tracing.md','lib/thread-manager.js','test/run.js','test/main-scheduler-observer.js','test/test-main-scheduler-observer.js','test/fixtures/main-scheduler-original.json']+['reports/airstrike-scheduler-decision-observer-oct27/'+p for p in ['README.md','evidence-index.json','evidence.tar.gz']]
accepted=['reports/airstrike-scheduler-observer-independent-accept-oct27/'+p for p in ['README.md','evidence-index.json','evidence.tar.gz']]
assert set(git(D,'diff-tree','--no-commit-id','--name-only','-r',C).decode().splitlines())==set(candidate)
assert set(git(AD,'diff-tree','--no-commit-id','--name-only','-r',A).decode().splitlines())==set(accepted)
for p in ['docs/tracing.md','lib/thread-manager.js','test/run.js','test/input-consumption-trace.js']:
 assert git(D,'show',C+'^:'+p)==git(B,'show',M+':'+p), 'unrelated production boundary change '+p
extra=['test/input-consumption-trace.js','tools/test-tiers.js','tools/check-test-manifest.sh','tools/check-test-timeouts.js','tools/test-timeouts.js','test/run-all.sh']
rows=[]
for repo,rev,paths in [(D,C,candidate),(AD,A,accepted),(B,M,extra)]:
 for p in paths:
  blob=git(repo,'rev-parse',rev+':'+p).decode().strip(); size=int(git(repo,'cat-file','-s',blob))
  rows.append(dict(path=p,revision=rev,donor=str(repo),blob=blob,bytes=size))
estimate=sum(r['bytes'] for r in rows)
save('materialization-estimate.json',dict(paths=rows,bytes=estimate,cap=8*1024**2,passGate=estimate<=8*1024**2,additionalReportAllowance=1024**2))
assert estimate+1024**2<=8*1024**2
R.mkdir(exist_ok=False); g=R/'.git'
for p in ['objects/info','refs/heads/task','info']: (g/p).mkdir(parents=True,exist_ok=True)
stores=[]
for donor in [D,AD,B]:
 stores.append(str(donor/'.git/objects'))
 alt=donor/'.git/objects/info/alternates'
 if alt.exists(): stores.extend(alt.read_text().splitlines())
(g/'objects/info/alternates').write_text('\n'.join(dict.fromkeys(stores))+'\n')
branch='task/airstrike-accepted-scheduler-main-integration-oct27'
(g/'HEAD').write_text('ref: refs/heads/'+branch+'\n'); (g/'refs/heads'/branch).write_text(M+'\n')
origin=git(B,'config','--get','remote.origin.url').decode().strip()
(g/'config').write_text('[core]\n repositoryformatversion = 0\n bare = false\n sparseCheckout = true\n[remote "origin"]\n url = '+origin+'\n[user]\n name = Wine Ops\n email = wine-ops@localhost\n')
(g/'info/sparse-checkout').write_text(''.join('/'+r['path']+'\n' for r in rows)+'/reports/airstrike-accepted-scheduler-main-integration-oct27/\n')
git(R,'read-tree',M)
for r in rows:
 b=git(pathlib.Path(r['donor']),'cat-file','blob',r['blob']); assert len(b)==r['bytes']; r['sha256']=sha(b)
 p=R/r['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
pins=json.loads((AD.parent/'ops/source-pins.json').read_text())
for p in pins:assert sha((R/p['path']).read_bytes())==p['sha256']
save('integrated-source-pins.json',rows)
save('identity-checkpoint.json',dict(main=M,candidate=C,acceptance=A,sourcePreserving=True,unchangedInputObserver='c8c85b12cfb76825ed64d2bc7a4a0afaea453ac5f3d1ba68f3db181ab4b146fe',candidatePaths=candidate,acceptancePaths=accepted,archiveVerification='reuse coordinator air-observer-verified.json and air-acceptance-verified.json; no historic payload replay',materializedBytes=estimate))
print('PASS exact 12-path accepted closure on current main; source pins unchanged; materialized',estimate,'bytes')
