'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const filename=path.resolve(__dirname,'../repo/test/test-main-scheduler-observer.js');
const source=fs.readFileSync(filename,'utf8');
const prefix=source.slice(0,source.indexOf('async function acceptance(parts)'));
const mod=new Module(filename,module);mod.filename=filename;mod.paths=Module._nodeModulePaths(path.dirname(filename));
mod._compile(prefix+'\nmodule.exports={harness,production,records};',filename);
const {harness,production:P,records}=mod.exports;
const events=h=>records(h.logs),inputRows=h=>events(h).filter(r=>r.event==='host-check-input'),first=[];
async function entry(parts) {
  for (const mode of ['ordinary','worker','cooperative']) {
    const off = harness(parts, { mode, now:25025 });
    const on = harness(parts, { mode, now:25025, enabled:true });
    await off.dispatch(); await on.dispatch();
    assert.equal(off.factoryCalls(),0,'default-off factory');
    assert.equal(off.observer(),null,'default-off init');
    assert.equal(off.wh.check_input,off.h.check_input,'default-off worker hook');
    assert.deepEqual(off.logs,[],'default-off output');
    assert.deepEqual(on.calls,off.calls,'entry semantics');
    assert.equal(on.factoryCalls(),1,'enabled factory');
    const rows = events(on), admissions = rows.filter(r=>r.event==='decision');
    const runs = rows.filter(r=>r.event==='main-run');
    assert(runs.length>0,'run wiring');
    for (const r of runs) {
      const d=admissions.find(d=>d.id===r.decisionId);
      assert(d && !d.suspended && d.path===r.path,'matching admitted run');
      assert(inputRows(on).some(i=>i.decisionId===d.id && i.scope==='admitted-main-run'),'matching input wiring');
    }
    first.push({mode,offFactory:off.factoryCalls(),enabledRows:rows.length});
  }
}

async function focused(parts) {
  // First behavioral checkpoint: actual production initialization, actual gate,
  // ordinary run call and host import entry, disabled then explicitly enabled.
  const off = harness(parts, { now: 25025 });
  await off.dispatch();
  assert.equal(off.factoryCalls(), 0, 'default-off must not initialize observer');
  assert.equal(off.observer(), null);
  assert.deepEqual(records(off.logs), [], 'default-off must emit nothing');
  assert.equal(off.wh.check_input, off.h.check_input, 'default worker import identity');
  assert.equal(off.calls.filter(x => Array.isArray(x) && x[0] === 'run').length, 1);
  const due = harness(parts, { enabled: true, now: 25025 });
  await due.dispatch();
  assert.equal(due.factoryCalls(), 1);
  const rows = records(due.logs);
  assert.deepEqual(rows.map(r => r.event), ['decision', 'main-run', 'host-check-input']);
  assert.equal(rows[0].sleepChecks.at(-1).now, 25025);
  assert.equal(rows[0].sleepChecks.at(-1).deadline, 25021);
  assert.equal(rows[0].suspended, false);
  assert.equal(rows[1].decisionId, rows[0].id);
  assert.equal(rows[2].decisionId, rows[0].id);
  assert.equal(rows[2].scope, 'admitted-main-run');
  assert.deepEqual(due.calls, off.calls, 'enabled observer must spend no extra getters/clocks');


}
(async()=>{
 await entry(P);
 console.log(JSON.stringify({phase:'integrated production boundary default-off/enabled',verdict:'PASS',first}));
 await focused(P);
 console.log(JSON.stringify({phase:'unchanged focused assertions from accepted affected test',verdict:'PASS',groupsReused:'57 dispatch / 6 FIFO / 7 controls; independent 12 adversarial / 4 controls',qualification:'exact contiguous production excerpts with stub exports; not full CLI, guest, gameplay or scheduler-cause proof'}));
})().catch(e=>{console.error(e.stack);process.exitCode=1});
