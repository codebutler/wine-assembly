import pathlib,json,hashlib,tarfile,io,datetime
O=pathlib.Path(__file__).parent;R=O.parent/'repo';P=R/'reports/airstrike-accepted-scheduler-main-integration-oct27';P.mkdir(parents=True,exist_ok=True)
def h(b):return hashlib.sha256(b).hexdigest()
payloads={}
for p in O.iterdir():
 if p.is_file() and p.name not in ['board-watch.log','report.stdout','report.stderr','report.supervisor-output','receipt-manifest.json']:
  payloads['ops/'+p.name]=p.read_bytes()
reused=[('/tmp/airstrike-scheduler-decision-observer-oct27/ops/receipt-manifest.json','reused/candidate-receipt.json'),('/tmp/airstrike-scheduler-observer-independent-accept-oct27/ops/receipt-manifest.json','reused/independent-receipt.json'),('/tmp/completions-1526-readiness-oct27/ops/air-observer-verified.json','reused/coordinator-candidate-verified.json'),('/tmp/completions-1526-readiness-oct27/ops/air-acceptance-verified.json','reused/coordinator-acceptance-verified.json'),('/tmp/completions-1526-readiness-oct27/ops/air-accept-ref.stdout','reused/acceptance-remote.stdout'),('/tmp/completions-1526-readiness-oct27/ops/air-accept-ref.json','reused/acceptance-remote.json'),('/home/user/wine-assembly/scratch/usage-watch/airstrike-accepted-scheduler-main-integration-oct27/root-ref-digest.json','reused/initial-root-ref-digest.json')]
for src,dest in reused:payloads[dest]=pathlib.Path(src).read_bytes()
assert sum(len(v) for v in payloads.values())<1024**2
rows=[]
with tarfile.open(P/'evidence.tar.gz','w:gz') as archive:
 for name,b in sorted(payloads.items()):
  t=tarfile.TarInfo(name);t.size=len(b);t.mtime=0;t.mode=0o644;archive.addfile(t,io.BytesIO(b));rows.append(dict(path=name,bytes=len(b),sha256=h(b)))
index=dict(schema=1,payloads=rows,archive=dict(path='evidence.tar.gz',bytes=(P/'evidence.tar.gz').stat().st_size,sha256=h((P/'evidence.tar.gz').read_bytes())),selfContained=True)
(P/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
(P/'README.md').write_text('''# Airstrike accepted scheduler observer integration

The default-off scheduler observer accepted at candidate `3a2cae66a6a32b3cebe05880564815062873b390` and independently accepted at `a217f896b5252a4eaaaaad2a2057ffcf76f92ce9` is integrated without source changes onto production main `3afff4f4e7fd50ee8ba25e01b01bd3c6c4b11af3`.

The complete integration contains all nine candidate paths and all three independent acceptance report paths. The existing input-consumption observer remains SHA-256 `c8c85b12cfb76825ed64d2bc7a4a0afaea453ac5f3d1ba68f3db181ab4b146fe`. No Wasm rebuild is required for this source observer.

Exact integrated runner and thread-manager identities match the accepted pins. The first behavioral verification uses the unchanged independent entry assertions with contiguous excerpts of those production sources. Ordinary, worker and cooperative dispatch pass disabled initialization/hook/output checks and explicitly enabled matched decision/run/host-input checks, with unchanged observable calls and ordering. The focused first-checkpoint assertions from `test/test-main-scheduler-observer.js` also pass unchanged. Accepted 57 dispatch comparisons, 6 FIFO cases and 7 controls, plus the independent 12 adversarial groups and 4 controls, are reused without replay.

The complete affected-test dependency closure is Node builtins, the supplied observer and the supplied fixture. The exact production tier classifier validates the complete immutable main test-name inventory plus the accepted delta: 2,158 tests, no tier errors, the new test automatically in UNIT. Affected timeout requirements pass the unchanged 300-second runner default. This bounded check does not claim a full-tree source timeout scan. All four affected JS files parse successfully. The exact Node executable, heap flag, clean environment and inherited unlimited DATA/AS startup are recorded. The heap flag is not a total-process memory limit.

These are source-excerpt/stub-export checks. They establish neither full CLI/guest/gameplay behavior nor a scheduler cause for the retained no-dequeue observation. No guest, build, Boat, deployment or unrelated repair was performed; Claude stayed idle and no workers were launched. The coordinator reports all prior test boxes stopped; no box queries or lifecycle operations occurred.

The checkout uses existing immutable object stores read-only, without network fetch, with a 1,341,042-byte initial materialized closure against the 8 MiB cap. Resource admission and cleanup receipts are retained. Initial policy/receipt displays exceeded the requested 8,192-byte per-operation display target; this operational incident did not change inputs, resource limits or test gates. Later result displays are bounded.

[`evidence-index.json`](evidence-index.json) hashes every portable payload in [`evidence.tar.gz`](evidence.tar.gz). The archive contains the integrated input identities, exact test scripts/results, resource/launch configuration, original canonical acceptance manifests and coordinator verification receipts. Historic archive payload verification is reused unchanged; those archives were not expanded or reverified. The accepted candidate and independent report directories are preserved alongside this report. Absolute historical paths inside receipts identify provenance; no report payload needs an external `/tmp` file to be read.

Publication is conditional on exact remote-main reconciliation, reviewed staged identities and passing gates under the shared Git lock. The terminal canonical worker receipt records the actual task/main SHAs, publication results and cleanup after this prepublication archive was sealed, avoiding self-referential Git hashes. Root tracked files, index and refs and all donor stores remain read-only; the root coordination messageboard alone receives append-only ownership/publication notes.
''')
(O/'report-seal.json').write_text(json.dumps(dict(payloads=len(rows),payloadBytes=sum(r['bytes'] for r in rows),reportPaths=[str(p.relative_to(R)) for p in P.iterdir()],archive=index['archive']),indent=2)+'\n')
print('PASS portable report sealed:',len(rows),'payloads; archive',index['archive']['bytes'],'bytes')
