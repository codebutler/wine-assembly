'use strict';
const {spawnSync}=require('node:child_process'),assert=require('node:assert/strict');
const files=['test/run.js','lib/thread-manager.js','test/main-scheduler-observer.js','test/test-main-scheduler-observer.js'];
for(const file of files){
 const r=spawnSync(process.execPath,['--max-old-space-size=512','--check',file],{stdio:'inherit'});
 assert.equal(r.status,0,file);assert.equal(r.signal,null,file);
}
console.log(JSON.stringify({syntax:'PASS',files,execution:'parse only; no runner/guest execution'}));
