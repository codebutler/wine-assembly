exec(open(__file__.replace('stage-review.py','prepare.py')).read().split('sources=')[0])
identity=json.loads((O/'identity-checkpoint.json').read_text()); paths=identity['candidatePaths']+identity['acceptancePaths']
report=['reports/airstrike-accepted-scheduler-main-integration-oct27/'+p for p in ['README.md','evidence-index.json','evidence.tar.gz']]
assert len(paths)==12
for row in json.loads((O/'integrated-source-pins.json').read_text()):assert sha((R/row['path']).read_bytes())==row['sha256']
git(R,'add','--sparse','--',*(paths+report))
actual=git(R,'diff','--cached','--name-only',M).decode().splitlines();assert set(actual)==set(paths+report),(actual,paths+report)
git(R,'diff','--cached','--check','--',*(paths+report))
for row in json.loads((O/'integrated-source-pins.json').read_text()):assert git(R,'rev-parse',':'+row['path']).decode().strip()==row['blob']
tree=git(R,'write-tree').decode().strip()
assert git(R,'rev-parse',tree+':test/input-consumption-trace.js')==git(R,'rev-parse',M+':test/input-consumption-trace.js')
delta=git(R,'diff','--cached','--stat','--',*(paths+report)).decode();(O/'staged-stat.txt').write_text(delta)
save('staged-review.json',dict(passGate=True,tree=tree,main=M,paths=actual,unchangedAcceptedBlobs=True,unchangedInputObserver=True,diffCheck='PASS',outsideClosureChanges=0,reportPayloadDependency='self-contained archives; original historical absolute paths are provenance only'))
print('PASS staged exact 15-path closure, all accepted blobs unchanged, diff check clean; tree',tree)
