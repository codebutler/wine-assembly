import os,sys,json,pathlib,importlib.util,subprocess,resource,hashlib,shutil,time
ROOT=pathlib.Path('/tmp/airstrike-accepted-scheduler-main-integration-oct27'); OPS=ROOT/'ops'
SUP=pathlib.Path('/tmp/gl-required-version-independent-integrate-oct26/repo/test/helpers/palette-browser-supervisor.py')
SSH='ssh -i /home/user/.ssh/wine_github_ed25519 -o BatchMode=yes -o IdentitiesOnly=yes -o UserKnownHostsFile=/home/user/.ssh/wine_github_known_hosts -o StrictHostKeyChecking=yes'
if sys.argv[1]=='child':
 name,kind,cwd,*cmd=sys.argv[2:]
 with open(OPS/(name+'.stdout'),'wb') as out,open(OPS/(name+'.stderr'),'wb') as err:
  def git_limits():
   resource.setrlimit(resource.RLIMIT_DATA,(512*1024**2,512*1024**2))
  marker=os.environ.get('PALETTE_BROWSER_SUPERVISED','')
  os.environ.clear()
  os.environ.update(PATH='/usr/local/bin:/usr/bin:/bin',HOME='/home/user',LANG='C.UTF-8',TZ='UTC',GIT_SSH_COMMAND=SSH,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',GIT_TERMINAL_PROMPT='0',PALETTE_BROWSER_SUPERVISED=marker)
  try:r=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=err,preexec_fn=git_limits if kind=='git' else None)
  except Exception as e:err.write((repr(e)+'\n').encode());sys.exit(125)
 sys.exit(r.returncode)
name,kind,cwd,*cmd=sys.argv[1:]
assert hashlib.sha256(SUP.read_bytes()).hexdigest()=='9d10f7c8c75b5f0dfebff2299eef8ddc27988cf112e0e9c255e89f772c2cee85'
spec=importlib.util.spec_from_file_location('trusted',SUP);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def allocated(p):
 total=0
 for base,ds,fs in os.walk(p):
  for f in fs:
   try:total+=os.lstat(os.path.join(base,f)).st_blocks*512
   except FileNotFoundError:pass
 return total
own=allocated(ROOT); launcher=allocated('/home/user/wine-assembly/scratch/usage-watch/airstrike-accepted-scheduler-main-integration-oct27')
session_id=os.environ.get('CODEX_THREAD_ID','')
sessions=list(pathlib.Path('/home/user/.codex/sessions/2026/10/27').glob('*'+session_id+'*')) if session_id else []
wals=list(pathlib.Path('/home/user/.codex').glob('*.sqlite-wal'))
external_files=[dict(path=str(p),logical=p.stat().st_size,allocated=p.stat().st_blocks*512) for p in sessions+wals]
# Initial WAL baseline unavailable: conservatively charge entire current shared WAL once.
external=sum(x['allocated'] for x in external_files)
rows=m.snapshot(); clients=[]
for pid,row in rows.items():
 try:
  raw=pathlib.Path('/proc',str(pid),'cmdline').read_bytes().split(b'\0')
  if raw and b'codex' in raw[0] and b'exec' in raw:clients.append(dict(pid=pid,rss=row['rss']))
 except OSError:pass
mem=int(next(l.split()[1] for l in pathlib.Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
# MemAvailable already excludes current RSS: reserve only each client's remaining growth.
remaining=sum(max(0,320*1024**2-c['rss']) for c in clients)
required=remaining+768*1024**2+805306368
free=shutil.disk_usage(ROOT).free
ad=dict(at=time.time(),ownAllocated=own,launcherAllocated=launcher,sessionAndConservativeFullWAL=external,externalFiles=external_files,walAccounting='full current WAL once because no initial baseline; shared current RSS not double counted',clients=clients,memAvailable=mem,remainingClientGrowth=remaining,sharedChild=768*1024**2,hostHeadroom=805306368,requiredRemaining=required,allocation=512*1024**2,futureBreakdown={'sourceReportsGitSessionEvents':96*1024**2,'controls':24*1024**2,'publication':16*1024**2,'reserve':32*1024**2,'margin':8*1024**2},projectedTask=own+launcher+external+176*1024**2,freeDisk=free,projectedDisk=free-872415232,diskFloor=2982150144,ssh=SSH,mountArgv=[],mountExecution='no guest/mount invocation authorized')
ad['pass']=mem>=required and ad['projectedDisk']>=ad['diskFloor'] and ad['projectedTask']<=ad['allocation']
(OPS/(name+'.admission.json')).write_text(json.dumps(ad,indent=2)+'\n')
if not ad['pass']:raise SystemExit('admission rejected')
argv=[sys.executable,__file__,'child',name,kind,cwd,*cmd]
if kind=='git':argv=['flock','/tmp/wine-ops-production-git.lock',*argv]
cap={'git':256,'python':128,'node':768}[kind]*1024**2
# Distinct child files are checked throughout; supervisor output is only wrapper diagnostics.
def check():
 sizes=[(OPS/(name+'.'+s)).stat().st_size if (OPS/(name+'.'+s)).exists() else 0 for s in ('stdout','stderr')]
 if sum(sizes)>2*1024**2:return 'distinct output limit'
 if allocated(ROOT)+allocated('/home/user/wine-assembly/scratch/usage-watch/airstrike-accepted-scheduler-main-integration-oct27')+sum(p.stat().st_blocks*512 for p in sessions+wals if p.exists())>512*1024**2-32*1024**2:return 'task allocation reserve'
 if shutil.disk_usage(ROOT).free-872415232<2982150144:return 'projected host disk floor'
r=m.supervise(argv,rss_limit=cap,cpu_limit=90,wall_limit=120,output_limit=2*1024**2,check=check)
(OPS/(name+'.supervisor-output')).write_bytes(r.pop('output'));r['command']=cmd;r['cwd']=cwd;r['limits']=dict(rss=cap,cpu=90,wall=120,file=24*1024**2,output=2*1024**2,gitDataOnly=kind=='git')
for suffix in ('stdout','stderr'):
 p=OPS/(name+'.'+suffix);r[suffix]=dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) if p.exists() else None
(OPS/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:r[k] for k in ('exit','stopReason','cleanupComplete','peakRSS','cpuSeconds')}))
sys.exit(0 if r['exit']==0 and r['stopReason'] is None and r['cleanupComplete'] else 1)
