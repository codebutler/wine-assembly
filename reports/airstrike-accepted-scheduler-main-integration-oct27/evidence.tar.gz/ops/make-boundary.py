import pathlib,json,hashlib
O=pathlib.Path(__file__).parent; R=O.parent/'repo'
original=(R/'test/test-main-scheduler-observer.js').read_text()
prefix=original[:original.index('async function acceptance(parts)')]
donor=pathlib.Path('/tmp/airstrike-scheduler-observer-independent-accept-oct27/ops/independent.js').read_text()
entry=donor[donor.index('async function entry(parts)'):donor.index('async function differential(parts,')]
focused=original[original.index('  // First behavioral checkpoint:'):original.index('  const cases = [')]
driver="""'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const filename=path.resolve(__dirname,'../repo/test/test-main-scheduler-observer.js');
const source=fs.readFileSync(filename,'utf8');
const prefix=source.slice(0,source.indexOf('async function acceptance(parts)'));
const mod=new Module(filename,module);mod.filename=filename;mod.paths=Module._nodeModulePaths(path.dirname(filename));
mod._compile(prefix+'\\nmodule.exports={harness,production,records};',filename);
const {harness,production:P,records}=mod.exports;
const events=h=>records(h.logs),inputRows=h=>events(h).filter(r=>r.event==='host-check-input'),first=[];
"""
driver+=entry+'\nasync function focused(parts) {\n'+focused+'\n}\n'
driver+="""(async()=>{
 await entry(P);
 console.log(JSON.stringify({phase:'integrated production boundary default-off/enabled',verdict:'PASS',first}));
 await focused(P);
 console.log(JSON.stringify({phase:'unchanged focused assertions from accepted affected test',verdict:'PASS',groupsReused:'57 dispatch / 6 FIFO / 7 controls; independent 12 adversarial / 4 controls',qualification:'exact contiguous production excerpts with stub exports; not full CLI, guest, gameplay or scheduler-cause proof'}));
})().catch(e=>{console.error(e.stack);process.exitCode=1});
"""
(O/'boundary.js').write_text(driver)
hash=lambda s:hashlib.sha256(s.encode()).hexdigest()
(O/'boundary-transform.json').write_text(json.dumps(dict(affectedTestSHA256=hash(original),scaffolding=dict(bytes=len(prefix.encode()),sha256=hash(prefix),recipe='prefix before async function acceptance(parts)'),entry=dict(bytes=len(entry.encode()),sha256=hash(entry),recipe='unchanged independent entry function before differential'),focused=dict(bytes=len(focused.encode()),sha256=hash(focused),recipe='unchanged affected test first behavioral checkpoint before const cases'),driverSHA256=hash(driver),productionSources='byte-identical accepted pinned runner/thread-manager; no historical runner substitution'),indent=2)+'\n')
print('PASS unchanged boundary/assertion extraction, broad groups not scheduled')
