const fs=require('fs'); console.log(JSON.stringify({exec:process.execPath,version:process.version,flags:process.execArgv,env:process.env,limits:fs.readFileSync('/proc/self/limits','utf8')}));
