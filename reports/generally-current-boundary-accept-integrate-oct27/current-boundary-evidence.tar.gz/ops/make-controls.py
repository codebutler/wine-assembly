from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent.parent;source=(R/'repo/tools/generally-loading-controller.py').read_text();records=[]
for mode in ('old-ordering','guard-omission'):
 root=R/'ops/controls'/mode;(root/'repo/tools').mkdir(parents=True);(root/'ops').mkdir()
 mutant=source.replace('if not dispatch_started:', 'if False:  # negative control: omit predispatch rollback')
 assert mutant!=source
 if mode=='old-ordering':
  old='        try:\n            reply = self.transport.exchange('
  assert source.count(old)==1
  mutant=mutant.replace(old,'        try:\n            reserve()  # negative control: reserve before transport preflight\n            reply = self.transport.exchange(')
 (root/'repo/tools/generally-loading-controller.py').write_text(mutant)
 for name in ('test/run.js','test/fixtures/generally-loading-current-protocol.cjs','test/input-consumption-trace.js','test/independent-generally-current-history-oct27.py','test/independent-generally-current-no-advance-oct27.py'):
  p=root/'repo'/name;p.parent.mkdir(parents=True,exist_ok=True);b=(R/'repo'/name).read_bytes()
  if name.endswith('no-advance-oct27.py'):b=b.replace(hashlib.sha256(source.encode()).hexdigest().encode(),hashlib.sha256(mutant.encode()).hexdigest().encode())
  p.write_bytes(b)
 for name in ('cli-race-entry.py','independent-boundary.py'):(root/'ops'/name).write_bytes((R/'ops'/name).read_bytes())
 records.append(dict(mode=mode,sourceSHA256=hashlib.sha256(mutant.encode()).hexdigest(),changes=['omit rollback']+(['reserve before preflight'] if mode=='old-ordering' else []),oracleIdentityOnlyRebinding=mode=='old-ordering'))
(R/'ops/controls.json').write_text(json.dumps(records,indent=2)+'\n')
