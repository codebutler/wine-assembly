import pathlib,json,hashlib,subprocess,resource,re
R=pathlib.Path(__file__).resolve().parent.parent; O=R/'ops'; repo=R/'repo'
def lim(): resource.setrlimit(resource.RLIMIT_DATA,(512*1024**2,512*1024**2))
def g(*a):return subprocess.check_output(['git',*a],cwd=repo,preexec_fn=lim)
plan=json.loads(pathlib.Path('/tmp/generally-cursor-integration-readiness-oct27/ops/integration-plan.json').read_text())
for x in plan['changedFiles']:
 b=(repo/x['path']).read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
 assert g('show',':'+x['path'])==b
assert g('show',plan['currentMain']+':test/run.js')==(repo/'test/run.js').read_bytes()
helper=repo/'test/input-consumption-trace.js'
assert g('show',plan['currentMain']+':test/input-consumption-trace.js')==helper.read_bytes()
assert not re.search(r'\brequire\s*\(',helper.read_text())
assert g('symbolic-ref','HEAD').decode().strip()=='refs/heads/task/generally-current-boundary-accept-integrate-oct27'
original=pathlib.Path('/tmp/generally-cursor-preflight-independent-accept-oct27/ops')
for name in ('independent-boundary.py','cli-race-entry.py'):
 assert (O/name).read_text()==(original/name).read_text().replace('generally-loading-protocol.cjs','generally-loading-current-protocol.cjs')
for old,new in [('independent-generally-no-advance-oct27.py','independent-generally-current-no-advance-oct27.py'),('independent-generally-history-oct27.py','independent-generally-current-history-oct27.py')]:
 expected=(repo/'test'/old).read_text().replace('independent-generally-history-oct27.py','independent-generally-current-history-oct27.py').replace('generally-loading-protocol.cjs','generally-loading-current-protocol.cjs')
 assert (repo/'test'/new).read_text()==expected
for name in ['boundary-first','input-state','race-reservation','race-journal','race-after-dispatch','merged-cursor-corrected','node-startup']:
 d=json.loads((O/(name+'.json')).read_text());assert d['exit']==0 and d['cleanupComplete'] and d['stopReason'] is None
old=O/'controls/old-ordering/ops'; assert 'cursor advanced beyond last acknowledged request' in (old/'oracle.stderr').read_text()
oldrow=json.loads((old/'oracle.stdout').read_text().splitlines()[-1]);assert oldrow['accepted'] is False and oldrow['actualCursor']['next']==64
guard=json.loads((O/'controls/guard-omission/ops/race-reservation/observation.json').read_text())
assert guard['cursor']['next']==64 and guard['requests']==['0061.json','0062.json']
assert guard['receipt']['error']=='consumed ACK changed or removed'
negative=json.loads((O/'control-guard-omission.json').read_text());assert negative['exit']==1 and negative['cleanupComplete'] and negative['stopReason'] is None
assert 'assert cursor' in (O/'control-guard-omission.stderr').read_text()
changed=g('diff','--cached','--name-only',plan['currentMain']).decode().splitlines()
assert sorted(changed)==sorted(x['path'] for x in plan['changedFiles'])
newPaths=['test/fixtures/generally-loading-current-protocol.cjs','test/independent-generally-current-history-oct27.py','test/independent-generally-current-no-advance-oct27.py','test/independent-generally-current-input-state-oct27.py']
pins=[]
for p in ['test/run.js','test/input-consumption-trace.js',*newPaths]:
 b=(repo/p).read_bytes();pins.append(dict(path=p,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)))
d=dict(accepted=True,source13Exact=True,runnerUnchanged=True,mainHelperExact=True,helperRequires=[],oracleAssertionsUnchanged=True,newPaths=newPaths,pins=pins,negativeControls=dict(oldOrdering='rejected next64 by unchanged no-advance oracle',rollbackOmission='rejected next64 by unchanged reservation-race oracle'),fullUnrelatedIndexTreePreserved=True)
(O/'review-result.json').write_text(json.dumps(d,indent=2)+'\n');print('PASS exact13-source/tree/runner/helper/fixture transforms and current-boundary acceptance review')
