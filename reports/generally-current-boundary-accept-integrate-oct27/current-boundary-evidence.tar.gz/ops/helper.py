import subprocess,resource,pathlib,json,hashlib
r=pathlib.Path(__file__).resolve().parent.parent
base='3370a4e72a72ef54ebcbcde5264b768a47e98590'
def lim():resource.setrlimit(resource.RLIMIT_DATA,(512*1024**2,512*1024**2))
p='test/input-consumption-trace.js'
b=subprocess.check_output(['git','show',base+':'+p],cwd=r/'repo',preexec_fn=lim)
(r/'repo'/p).write_bytes(b)
(r/'ops/helper-pin.json').write_text(json.dumps(dict(path=p,main=base,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))))
print(b.decode())
