"""Instrumentation wraps durable writes; unmodified controller.main owns CLI and transport."""
import importlib.util,json,sys,subprocess
from pathlib import Path
helper,mode,case,*args=sys.argv[1:];d=Path(case)
spec=importlib.util.spec_from_file_location('candidate',helper);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
original=m.atomic;triggered=False

def atomic(path,value):
 global triggered
 original(path,value)
 p=Path(path)
 hit=(mode=='reservation' and p==d/'cursor' and value.get('request',{}).get('id')==63) or (mode=='journal' and p.suffix=='.journal' and value.get('pending',{}).get('id')==63) or (mode=='after-dispatch' and p.parent.name=='requests' and value.get('id')==63)
 if hit and not triggered:
  triggered=True
  other=d/'competing.cursor';original(other,dict(next=63,pending=False));before=other.read_bytes()
  cmd=[sys.executable,'-B',helper,'--mailbox',str(d/'mailbox'),'--state',str(other),'--receipt',str(d/'competing.receipt'),'--total','1','--deadline-seconds','1']
  with (d/'competing.stdout').open('wb') as out,(d/'competing.stderr').open('wb') as err:
   result=subprocess.run(cmd,stdout=out,stderr=err,timeout=3)
  assert result.returncode==1 and other.read_bytes()==before
  assert json.loads((d/'competing.receipt').read_text())['events']==[]
  ack=d/'mailbox/replies/0061.json';ack.write_bytes(ack.read_bytes()+b' ')
  (d/'hook.json').write_text(json.dumps(dict(mode=mode,path=str(path),value=value,competingExit=result.returncode,ackMutation='append single space to consumed ACK61')))
m.atomic=atomic
sys.argv=[helper,*args];sys.exit(m.main())
