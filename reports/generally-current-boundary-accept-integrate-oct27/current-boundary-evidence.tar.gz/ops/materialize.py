import pathlib,json,hashlib,subprocess,resource
R=pathlib.Path('/tmp/generally-current-boundary-accept-integrate-oct27');repo=R/'repo';ops=R/'ops'
planpath=pathlib.Path('/tmp/generally-cursor-integration-readiness-oct27/ops/integration-plan.json');assert hashlib.sha256(planpath.read_bytes()).hexdigest()=='7ff12357d122ee44b98e7e92fea90d2fa26d8aad8b6beb413b85401859913bf8';plan=json.loads(planpath.read_text())
(repo/'.git/objects/info/alternates').write_text('/tmp/generally-cursor-integration-readiness-oct27/objects.git/objects\n/tmp/generally-accepted-cursor-main-integration-oct27/repo/.git/objects\n')
(repo/'.git/config').write_text('[core]\n repositoryformatversion = 0\n filemode = true\n bare = false\n sparseCheckout = true\n[user]\n name = Wine Ops\n email = wine-ops@localhost\n[remote "origin"]\n url = git@github.com:vgrichina/wine-assembly.git\n[gc]\n auto = 0\n')
def limits():resource.setrlimit(resource.RLIMIT_DATA,(512*1024**2,512*1024**2))
def g(*args):return subprocess.check_output(['git',*args],cwd=repo,preexec_fn=limits)
base=plan['currentMain'];candidate=plan['acceptedCommit']
(repo/'.git/info/sparse-checkout').write_text('/test/run.js\n'+''.join('/'+x['path']+'\n' for x in plan['changedFiles']))
g('read-tree',base);g('update-ref','refs/heads/task/generally-current-boundary-accept-integrate-oct27',base)
rows=[]
for x in plan['changedFiles']:
 assert not g('ls-tree',base,'--',x['path']).strip()
 b=g('show',candidate+':'+x['path']);assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'];p=repo/x['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 row=g('ls-tree',candidate,'--',x['path']).decode().strip();mode,typ,blobpath=row.split(None,2);blob=blobpath.split('\t')[0]
 g('update-index','--add','--cacheinfo',mode,blob,x['path']);rows.append(dict(x,blob=blob,mode=mode))
b=g('show',base+':test/run.js');(repo/'test/run.js').write_bytes(b)
s=b.decode();a=s.index('  const liveOutstanding = new Map();');z=s.index('\n\n  // A rejected async loader/yield',a);boundary=s[a:z].encode();h=hashlib.sha256(boundary).hexdigest();assert h=='366711bfa9a7eb1694104a63368361370e8612eb002a3d5b4acc025d2fd9a5a1' and len(boundary)==16268
fixture=repo/'test/fixtures/generally-loading-protocol.cjs';old='6dc104b3c10db701c0b1aec5954dd00cc29a7b6009970a5876ccc27426e7fa9e';new=hashlib.sha256(b).hexdigest();text=fixture.read_text();assert text.count(old)==1
(ops/'fixture-main.cjs').write_text(text.replace(old,new))
receipt=dict(baseline=base,candidate=candidate,materialized=rows,sourceBytes=sum(x['bytes'] for x in rows),runnerSHA256=new,runnerBlob=g('rev-parse',base+':test/run.js').decode().strip(),productionBoundary=dict(start=a,end=z,bytes=len(boundary),sha256=h,historicalBoundaryIdentical=False),fixtureReplay=dict(sourceSHA256=hashlib.sha256(fixture.read_bytes()).hexdigest(),replaySHA256=hashlib.sha256((ops/'fixture-main.cjs').read_bytes()).hexdigest(),transformation='replace exactly one full-runner identity literal '+old+' with '+new+'; behavioral assertions and extraction unchanged'),mountArgv=[],mountValidation='no filename-bearing mount or guest command; canonical parser inapplicable',ssh='exact user-configured GIT_SSH_COMMAND; no trust changes',readOnlyAlternate='/tmp/generally-cursor-integration-readiness-oct27/objects.git/objects',fetchBytes=0)
(ops/'materialization.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(dict(sourceBytes=receipt['sourceBytes'],runner=new,boundary=h,paths=len(rows))))
