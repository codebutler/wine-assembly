from pathlib import Path
import subprocess,json
O=Path(__file__).resolve().parent
rows=[]
for mode in ('old-ordering','guard-omission'):
 r=O/'controls'/mode
 with (r/'ops/oracle.stdout').open('wb') as out,(r/'ops/oracle.stderr').open('wb') as err:
  p=subprocess.run(['python3','-B',str(r/'repo/test/independent-generally-current-no-advance-oct27.py'),'--reproduce',str(r/'ops/no-advance')],stdout=out,stderr=err,timeout=10)
 assert p.returncode==1
 error=(r/'ops/oracle.stderr').read_text()
 assert 'cursor advanced beyond last acknowledged request' in error,error
 d=json.loads((r/'ops/oracle.stdout').read_text().splitlines()[-1])
 assert d['actualCursor']['next']==64 and d['accepted'] is False and d['noRequest63'] is True
 rows.append(dict(mode=mode,exit=p.returncode,expectedRejected=True,diagnostic=d))
(O/'negative-results.json').write_text(json.dumps(rows,indent=2)+'\n')
print('PASS both negative controls rejected unchanged cursor oracle')
