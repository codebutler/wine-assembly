import pathlib,json,subprocess,resource,hashlib
R=pathlib.Path(__file__).resolve().parent.parent;O=R/'ops';repo=R/'repo'
def lim():resource.setrlimit(resource.RLIMIT_DATA,(512*1024**2,512*1024**2))
def g(*a,input=None):return subprocess.check_output(['git',*a],cwd=repo,preexec_fn=lim,input=input)
m=json.loads((O/'receipt-manifest.json').read_text()); assert m['status']=='ACCEPT_CURRENT_PRODUCTION_BOUNDARY'
review=json.loads((O/'review-result.json').read_text());plan=json.loads(pathlib.Path('/tmp/generally-cursor-integration-readiness-oct27/ops/integration-plan.json').read_text())
reports=sorted(str(p.relative_to(repo)) for p in (repo/'reports/generally-current-boundary-accept-integrate-oct27').iterdir())
new=review['newPaths']+reports
for p in new:
 assert not g('ls-tree',m['baseline'],'--',p).strip()
 blob=g('hash-object','-w','--',p).decode().strip();g('update-index','--add','--cacheinfo','100644',blob,p)
expected=sorted(new+[x['path'] for x in plan['changedFiles']])
actual=g('diff','--cached','--name-only',m['baseline']).decode().splitlines(); assert actual==expected,(actual,expected)
assert not g('diff','--cached','--name-only','--diff-filter=DMRT',m['baseline']).strip()
g('diff','--cached','--check',m['baseline'])
tree=g('write-tree').decode().strip()
assert g('rev-parse',tree+':test/run.js')==g('rev-parse',m['baseline']+':test/run.js')
assert g('rev-parse',tree+':test/input-consumption-trace.js')==g('rev-parse',m['baseline']+':test/input-consumption-trace.js')
commit=g('commit-tree',tree,'-p',m['baseline'],'-m','Integrate GeneRally fail-closed controller with current-boundary acceptance').decode().strip()
ref='refs/heads/task/generally-current-boundary-accept-integrate-oct27'
g('update-ref',ref,commit,m['baseline'])
(O/'commit-result.json').write_text(json.dumps(dict(commit=commit,tree=tree,parent=m['baseline'],ref=ref,paths=expected,fullUnrelatedTreePreserved=True),indent=2)+'\n')
print(json.dumps(dict(commit=commit,tree=tree,paths=len(expected),parent=m['baseline'])))
