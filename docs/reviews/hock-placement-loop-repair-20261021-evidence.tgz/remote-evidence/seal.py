import pathlib, hashlib, json, subprocess
r=pathlib.Path('/home/user/hock-placement-loop-repair'); repo=r/'repo'
baseline=pathlib.Path('/home/user/hock-accepted-canonical-runtime')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a): return subprocess.check_output(['git','-C',str(repo),*a])
assert git('rev-parse','HEAD').decode().strip()=='7e5cf3535946e0a7bf42179b728a8471dc9f6b67'
old=json.loads((baseline/'source-seals.json').read_text())
new={f:sha(repo/f) for f in old}
delta={f:{'base':old[f],'candidate':new[f]} for f in old if old[f]!=new[f]}
assert list(delta)==['src/09a5b-handlers-window-late.wat'],delta
new['test/test-window-placement-client.js']=sha(repo/'test/test-window-placement-client.js')
(r/'source-seals.json').write_text(json.dumps(new,indent=2))
pkg=json.loads((baseline/'package-seals.json').read_text())
for f,h in pkg.items(): assert sha(baseline/'intake'/f)==h,f
assert len([f for f in pkg if f.startswith('game/')])==39
(r/'package-seals.json').write_text(json.dumps(pkg,indent=2))
patch=git('diff'); (r/'tested.patch').write_bytes(patch)
identity=dict(base='7e5cf3535946e0a7bf42179b728a8471dc9f6b67',
 base_tree=git('rev-parse','HEAD^{tree}').decode().strip(),delta=delta,
 source_seals_sha256=sha(r/'source-seals.json'),package_seals_sha256=sha(r/'package-seals.json'),
 patch_sha256=sha(r/'tested.patch'),new_test_sha256=new['test/test-window-placement-client.js'],
 wasm_sha256=sha(repo/'build/wine-assembly.wasm'),compat_sha256=sha(repo/'build/wine-assembly.compat.wasm'),
 baseline_wasm_sha256=sha(baseline/'repo/build/wine-assembly.wasm'),
 node=subprocess.check_output(['node','--version']).decode().strip(),package_count=39)
assert identity['baseline_wasm_sha256']=='7ebd28d0ee057c6aec01be9775b456726113083f2e76a4dd9767bb93e2a0b2bd'
(r/'identity.json').write_text(json.dumps(identity,indent=2)); print(json.dumps(identity,indent=2))
