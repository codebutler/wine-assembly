# Hock placement repair recovery — 2026-10-21

SAME Boat `bx_3f3x23m3` remains running, TTL 05:56:19.894Z. The coordinator
owns shutdown; this worker issued no lifecycle actions. Use Boat exec/file APIs.

Accepted baseline is untouched at `/home/user/hock-accepted-canonical-runtime`.
Candidate is separately retained at `/home/user/hock-placement-loop-repair/repo`.
Both have dependencies and canonical modules. Original assets remain under
the baseline's `intake/game` (39 files); `package-seals.json` proves identity.
The original recovery script remains in the baseline intake evidence.

Candidate base: `7e5cf3535946e0a7bf42179b728a8471dc9f6b67`.
Apply `remote-evidence/tested.patch` to that revision and add the committed
`test/test-window-placement-client.js`. Install lockfile dependencies with
`npm ci` if recovering elsewhere. Build with `bash tools/build.sh` on the remote
host only. No game-specific skips, registrations, assets or output were changed.

Candidate module SHA256:
`eafeaa142c98fe60c489865c89a676c20afffe51002fe36799f42aa46d19ac2c`.
Baseline module SHA256:
`7ebd28d0ee057c6aec01be9775b456726113083f2e76a4dd9767bb93e2a0b2bd`.
Full source/package/module identities are in `remote-evidence/identity.json`,
`source-seals.json` and `package-seals.json`. Never label the candidate module
as an unchanged exact-main build.

Run from candidate repo:

```sh
timeout 45s node test/run.js --no-build --exe=/home/user/hock-accepted-canonical-runtime/intake/game/BBLOOGIE.EXE --exe-guest-path='C:\BBLOOGIE.EXE' --cwd='C:\' --vfs-include='**/*' --quiet-api --max-seconds=30 --max-batches=1000000 --png=../startup-bounded.png
```

For the startup placement trace use `--max-seconds=5 --max-batches=250`
and `--trace-api=GetWindowPlacement,GetWindowRect,GetClientRect,SetWindowPlacement
--trace-api-counts`. It records two placement calls, then exits the sizing loop.
Do not overwrite archived captures when repeating. Exact commands/Boat command
IDs are preserved in the run receipts.

Source regression: `node test/test-window-placement-client.js`. On baseline it
fails with client 392×272 instead of 500×348; candidate passes 15 cases.
`controls.py` tests wrong ordering and omitted host synchronization, restoring
the source in a finally block. It is tied to the candidate path above; run only
with exclusive ownership. `related-tests.command.txt` lists adjacent checks.

The 30-second screenshot shows the original start/character-selection screen,
not solid teal. No input, gameplay or audio acceptance was attempted. The right
character is partly clipped in this capture; no rendering-completeness claim.
Independent review is required before main integration. This bounded task ends
with placement correction evidence, without additional game work.
