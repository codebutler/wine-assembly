import pathlib, subprocess, hashlib, json
root = pathlib.Path('/home/user/hock-placement-loop-repair')
p = root/'repo/src/09a5b-handlers-window-late.wat'
original = p.read_text()
start = original.index('  (func $handle_SetWindowPlacement ')
end = original.index('\nGetTopWindow', start)
body = original[start:end]
refresh = '    (call $defwndproc_do_nccalcsize (local.get $arg0))\n'
assert body.count(refresh) == 1
sync_start = body.index('    (call $host_sync_window_client')
sync_end = body.index('    ;; showCmd', sync_start)
mutations = {
    'refresh-before-move': body.replace(refresh, '').replace('    ;; Move window to rcNormalPosition', refresh+'    ;; Move window to rcNormalPosition'),
    'omit-host-sync': body[:sync_start] + body[sync_end:],
}
results = []
try:
    for name, mutated in mutations.items():
        p.write_text(original[:start]+mutated+original[end:])
        proc = subprocess.run(['timeout','120s','node','test/test-window-placement-client.js'], cwd=root/'repo', stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        (root/(name+'.log')).write_text(proc.stdout)
        print(name, proc.returncode, proc.stdout[-1600:])
        assert proc.returncode == 1 and 'AssertionError' in proc.stdout
        results.append(dict(name=name,exit=proc.returncode,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
finally:
    p.write_text(original)
(root/'controls.json').write_text(json.dumps(dict(results=results,restored_sha256=hashlib.sha256(p.read_bytes()).hexdigest()),indent=2))
