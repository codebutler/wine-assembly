import subprocess,json,base64,pathlib,hashlib,concurrent.futures,tarfile
r=pathlib.Path(__file__).parent
size=5292061; chunk=400000
def get(off):
 cmd="import base64;f=open('/home/user/hock-toolbar-options-repair.tgz','rb');f.seek(%d);print(base64.b64encode(f.read(%d)).decode())"%(off,chunk)
 p=subprocess.run(['boat','exec','bx_egnm3u4y','--json','--','python3','-c',cmd],capture_output=True,text=True,check=True)
 j=json.loads(p.stdout);assert j['exitCode']==0 and not j.get('stdoutTruncated'),j
 data=base64.b64decode(j['stdout']);assert len(data)==min(chunk,size-off)
 return data
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool: data=b''.join(pool.map(get,range(0,size,chunk)))
assert hashlib.sha256(data).hexdigest()=='da1f5ca7fae7a9a3f523c09370190d43f8b39a285c6355232854ce0bf19a2a20'
(r/'remote-evidence.tgz').write_bytes(data)
with tarfile.open(r/'remote-evidence.tgz') as t:t.extractall(r/'remote-evidence',filter='data')
out=r/'remote-evidence/hock-toolbar-options-repair'
seals=json.loads((out/'SHA256SUMS.json').read_text())
for n,h in seals.items():assert hashlib.sha256((out/n).read_bytes()).hexdigest()==h,n
print('PASS archive and',len(seals),'seals')
