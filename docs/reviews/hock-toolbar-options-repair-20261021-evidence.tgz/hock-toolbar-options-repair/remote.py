import subprocess,json,pathlib,sys
run=pathlib.Path(__file__).parent
label=sys.argv[1];command=sys.stdin.read()
(run/(label+'.command.txt')).write_text(command)
p=subprocess.run(['boat','exec','bx_egnm3u4y','--json','--timeout','180','--','bash','-lc',command],text=True,capture_output=True)
(run/(label+'.json')).write_text(p.stdout)
if p.stderr:print(p.stderr)
r=json.loads(p.stdout);print(r.get('stdout',''));print(r.get('stderr',''),file=sys.stderr)
raise SystemExit(r.get('exitCode',p.returncode))
