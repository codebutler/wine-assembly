const fs=require('fs'),path=require('path'),http=require('http'),crypto=require('crypto');
const repo='/home/user/hock-registered-runtime/repo',out='/home/user/hock-toolbar-options-repair/input-paced';fs.mkdirSync(out);
const {createRequire}=require('module'),req=createRequire(repo+'/package.json');
const {buildCatalog,launchFor,createEmulatorHandler}=req('./ops/emulator-server');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
 const catalog=await buildCatalog(repo),candidate=req('./test/candidate-corpus/manifest.json').candidates.find(c=>c.id==='hock-a-loogie-1995');
 const wasmSha256=hash(fs.readFileSync(repo+'/build/wine-assembly.wasm'));
 const launch=launchFor(candidate,catalog,null,{wasmSha256});fs.writeFileSync(out+'/route.json',JSON.stringify(launch,null,2));
 if(!launch.routes[0]?.available)throw Error('No available route');
 const serve=createEmulatorHandler(repo),requests=[];
 const server=http.createServer(async(q,s)=>{s.on('finish',()=>requests.push({url:q.url,status:s.statusCode}));try{if(!await serve(q,s)){s.writeHead(404);s.end();}}catch(e){s.writeHead(500);s.end(e.stack);}});
 await new Promise(r=>server.listen(18765,'127.0.0.1',r));
 const puppeteer=req('puppeteer');const browser=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:true,args:['--no-sandbox','--disable-dev-shm-usage'],protocolTimeout:30000});
 try{
 const page=await browser.newPage();await page.setViewport({width:1100,height:850});const logs=[];
 page.on('console',m=>logs.push({type:m.type(),text:m.text()}));page.on('pageerror',e=>logs.push({error:e.stack}));
 const events=[];const started=Date.now();const event=(action,data={})=>events.push({utc:new Date().toISOString(),wallMs:Date.now()-started,action,...data});
 const responses=[];page.on('response',async r=>{if(/\.wasm(?:\?|$)|hock-a-loogie-1995/.test(r.url())){try{const b=await r.buffer();responses.push({url:r.url(),status:r.status(),bytes:b.length,sha256:hash(b)});}catch(e){responses.push({url:r.url(),error:String(e)});}}});
 const route='http://127.0.0.1:18765'+launch.routes[0].url;
 const entry='http://127.0.0.1:18765/emulator/?debug';
 await page.goto(entry,{waitUntil:'domcontentloaded',timeout:30000});
 await page.waitForSelector('#app-select option[value=hock_a_loogie]');
 await page.select('#app-select','hock_a_loogie');event('select',{selector:'#app-select',value:'hock_a_loogie'});
 await page.screenshot({path:out+'/browser-selected.png'});
 await page.click('button[onclick="launchApp()"]');event('click',{selector:'button[onclick="launchApp()"]'});
 const delay=ms=>new Promise(r=>setTimeout(r,ms));await delay(15000);
 await page.screenshot({path:out+'/selection.png'});
 // Real browser mouse input only; coordinates are screenshot pixels.
 await page.mouse.move(154,650);event('mousemove',{x:154,y:650});await delay(1000);
 await page.mouse.down();event('mousedown');await delay(1500);await page.mouse.up();event('mouseup');
 await delay(3500);await page.screenshot({path:out+'/started.png'});
 for(let i=0;i<36;i++){
  await page.mouse.move(378,462);event('mousemove',{x:378,y:462});await delay(50);
  await page.mouse.down();event('mousedown');await delay([650,800,950][i%3]);
  await page.mouse.up();event('mouseup');await delay(650);
  if(i%6===0)await page.screenshot({path:out+'/shot-'+String(i).padStart(2,'0')+'.png'});
 }
 await page.screenshot({path:out+'/final.png'});
 fs.writeFileSync(out+'/events.json',JSON.stringify(events,null,2));
 const state=await page.evaluate(()=>({url:location.href,isolated:crossOriginIsolated,status:document.querySelector('#status')?.textContent,selected:document.querySelector('#app-select')?.value,options:[...document.querySelectorAll('#app-select option')].filter(o=>o.value.includes('hock')).map(o=>({value:o.value,text:o.textContent})),text:document.body.innerText,windows:Object.values(window.sharedRenderer?.windows||{}).map(w=>({hwnd:w.hwnd,title:w.title,x:w.x,y:w.y,w:w.w,h:w.h,clientX:w.clientX,clientY:w.clientY})),canvases:[...document.querySelectorAll('canvas')].map(c=>({id:c.id,width:c.width,height:c.height,rect:c.getBoundingClientRect().toJSON()}))}));
 fs.writeFileSync(out+'/state.json',JSON.stringify(state,null,2));fs.writeFileSync(out+'/console.json',JSON.stringify(logs,null,2));fs.writeFileSync(out+'/responses.json',JSON.stringify(responses,null,2));fs.writeFileSync(out+'/requests.json',JSON.stringify(requests,null,2));fs.writeFileSync(out+'/runtime.json',JSON.stringify({browser:await browser.version(),route,entry,elapsedMs:Date.now()-started,events:events.length},null,2));console.log(JSON.stringify({browser:await browser.version(),route,status:state.status,selected:state.selected,options:state.options,events:events.length},null,2));
 }finally{await browser.close();await new Promise(r=>server.close(r));}
})().catch(e=>{console.error(e);process.exitCode=1});
