#!/usr/bin/env python3
"""Recover this intake's original bytes only; never installs or executes guests.
Run: python3 /path/to/recover.py (writes beside this script).
No retries or alternate hosts on HTTP/access failure.
"""
import hashlib
import io
import os
from pathlib import Path, PurePosixPath
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
FLOOR = 2285895680
LIMIT = 32 * 1024 * 1024
URL = 'https://archive.org/download/Hock-A-Loogie-1995/beavislg.zip'
SHA256 = 'e10d150131258641af11609249ac7f1c430e67e4138943d175b0365ba64be00b'

def guard(extra=0):
    used = sum(f.stat().st_size for f in ROOT.rglob('*') if f.is_file())
    st = os.statvfs(ROOT)
    assert used + extra <= LIMIT, '32 MiB allocation exceeded'
    assert st.f_bavail * st.f_frsize >= FLOOR + LIMIT - used, 'capacity floor'

def save(relative, data):
    dst = ROOT / relative
    assert not dst.is_symlink()
    if dst.exists():
        assert dst.read_bytes() == data, f'Existing bytes differ: {relative}'
        return
    guard(len(data))
    dst.parent.mkdir(parents=True, exist_ok=True)
    with dst.open('xb') as f:
        f.write(data)

guard()
outer = ROOT / 'beavislg.zip'
if outer.exists():
    data = outer.read_bytes()
else:
    with urllib.request.urlopen(URL, timeout=60) as response:
        data = response.read(1256579)
assert len(data) == 1256578
assert hashlib.sha256(data).hexdigest() == SHA256
save('beavislg.zip', data)
for archive, prefix in [(data, 'extracted')]:
    with zipfile.ZipFile(io.BytesIO(archive)) as z:
        for info in z.infolist():
            assert not PurePosixPath(info.filename).is_absolute()
            assert '..' not in PurePosixPath(info.filename).parts
            save(prefix + '/' + info.filename, z.read(info))
inner = (ROOT / 'extracted/BEAVISLG.ZIP').read_bytes()
assert hashlib.sha256(inner).hexdigest() == '24da14e65b7a5418f9f4099a8ec6dcf6998004c350f365936b8d9ef0b6a3f05e'
with zipfile.ZipFile(io.BytesIO(inner)) as z:
    for info in z.infolist():
        assert not PurePosixPath(info.filename).is_absolute()
        assert '..' not in PurePosixPath(info.filename).parts
        save('game/' + info.filename, z.read(info))
assert hashlib.sha256((ROOT / 'game/BBLOOGIE.EXE').read_bytes()).hexdigest() == '974f1b5ff82cfdb87f05b9840ae03cd2ed6ceebe2c8ed547253dadaf1a871ef4'
print('Original archive and all extracted bytes verified; no guest executed.')
