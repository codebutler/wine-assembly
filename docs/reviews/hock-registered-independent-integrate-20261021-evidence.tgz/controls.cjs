const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const {createRequire}=require('module'),cp=require('child_process');
const filename=path.join(__dirname,'repo/test/test-cli-candidate-corpus.js');
let child;const moduleObject={exports:{}};const realRequire=createRequire(filename);
const requireStub=n=>n==='child_process'?{spawnSync:()=>child}:realRequire(n);
vm.runInNewContext(fs.readFileSync(filename,'utf8'),{require:requireStub,module:moduleObject,__dirname:path.dirname(filename),process,console,Buffer},{filename});
const run=moduleObject.exports.runCandidate;
const check=(label,result,want)=>{child=result;const got=run({id:'independent-control',cli:{}},'/original/BBLOOGIE.EXE','/module.wasm');assert.equal(got.status,want,label);console.log(JSON.stringify({label,...got}));};
const warn=fs.readFileSync(path.join(__dirname,'sealed/remote-evidence/registered-final/guest.stderr.log'),'utf8');
for(const marker of ['*** CRASH at batch 7: unreachable','STUCK at EIP=404340 after 51 batches','WebAssembly.RuntimeError: memory access out of bounds','WebAssembly.LinkError: incompatible import','[worker] RuntimeError: unreachable','[fatal] crash: invalid opcode','UNIMPLEMENTED API: MissingFunction','cannot resolve required.dll','failed to load required.dll'])
  check(marker,{status:0,stdout:marker,stderr:warn},'BLOCKED');
for(const [label,result] of [['exit1',{status:1}],['signal',{status:null,signal:'SIGKILL'}],['timeout',{status:null,signal:'SIGKILL',error:{code:'ETIMEDOUT'}}],['compile',{status:0,stdout:'[CompileError: invalid module'}]])
  check(label,{stdout:'',stderr:warn,...result},label==='compile'?'HARNESS':'BLOCKED');
check('actual clean startup plus conditional warning',{status:0,stdout:fs.readFileSync(path.join(__dirname,'sealed/remote-evidence/registered-final/guest.stdout.log'),'utf8'),stderr:warn},'READY');
// A real WebAssembly trap, caught by a child that exits zero: output must block it.
const trapped=cp.spawnSync(process.execPath,['-e',`const m=new WebAssembly.Module(Buffer.from('0061736d0100000001040160000003020100070501016600000a05010300000b','hex'));try{new WebAssembly.Instance(m).exports.f()}catch(e){console.log(e.stack)}`],{encoding:'utf8',timeout:5000,killSignal:'SIGKILL'});
assert.equal(trapped.status,0);assert.match(trapped.stdout,/RuntimeError: unreachable/);
check('real wasm trap caught with exit0',trapped,'BLOCKED');
const timed=cp.spawnSync(process.execPath,['-e',"process.on('SIGTERM',()=>{}); console.log(process.pid); while(true){}"],{encoding:'utf8',timeout:1000,killSignal:'SIGKILL'});
assert.equal(timed.error.code,'ETIMEDOUT');assert.equal(timed.signal,'SIGKILL');
const pid=Number(timed.stdout.trim());assert(pid>0);assert.throws(()=>process.kill(pid,0),e=>e.code==='ESRCH');
check('real hard timeout; PID absent',timed,'BLOCKED');
// Document the precise lexical scope. Unknown suffixed diagnostic labels are not covered.
for(const marker of ['crashes as "<ord>"','RuntimeErrorExtra','CRASHED','CRASH_worker'])
  check('lexical scope: '+marker,{status:0,stdout:marker,stderr:''},'READY');
