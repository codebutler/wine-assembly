import pathlib,json,hashlib,subprocess,time,os,signal
base=pathlib.Path('/home/user/hock-registered-runtime');repo=base/'repo'
prior=pathlib.Path('/home/user/hock-registered-timeout-repair/evidence')
out=pathlib.Path('/home/user/hock-registered-independent-integrate');out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((base/'evidence/source-sha256.json').read_text())
changed={n:sha(repo/n) for n,h in source.items() if sha(repo/n)!=h}
assert changed==json.loads((prior/'identity.json').read_text())['changed']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()=='d4ba733fb0d1c9e6d67ff0db715a5c0535307e6f'
seals=json.loads((base/'evidence/accepted-package-seals.json').read_text());fixture=repo/'test/binaries/candidates/hock-a-loogie-1995'
for n,h in seals.items():
 assert sha(base/'intake'/n)==h,n
 if n.startswith('game/'):assert sha(fixture/n)==h,n
inventory=json.loads((fixture/'.wine-assembly-browser.json').read_text());assert len(inventory['files'])==38
for f in inventory['files']:
 p=fixture/f['url'];assert sha(p)==seals[f['url']] and p.stat().st_size==f['size'] and f['vfsPath']=='c:\\'+p.name
for evidence in [base/'evidence',prior]:
 checks=json.loads((evidence/'SHA256SUMS.json').read_text())
 for n,h in checks.items():assert sha(evidence/n)==h,n
assert sha(repo/'build/wine-assembly.wasm')=='728e1de80ec20a284fc41b339895ee8ac29f16e4ded83325b27576cfacd4466c'
env=dict(os.environ,NODE_OPTIONS='--require=/home/user/hock-registered-timeout-repair/observe-v2.cjs',HOCK_OBSERVE_DIR=str(out))
start=time.monotonic();args=['node','test/test-cli-candidate-corpus.js','--id=hock-a-loogie-1995','--strict']
with (out/'corpus.log').open('w') as log:
 p=subprocess.Popen(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=p.wait(timeout=75)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();raise
assert code==0,(out/'corpus.log').read_text()
vfs=json.loads((out/'actual-vfs-resolution.json').read_text());assert len(vfs['files'])==39
for f in vfs['files']:assert f['sha256']==seals['game/'+f['guestPath']]
command=json.loads((out/'actual-child-command.json').read_text());assert command['wasmSha256']=='a5972cbaf915aa1d155b301da5fae1c80298b2be381034945c7e58cc81e02f72'
processes=subprocess.check_output(['ps','-eo','pid,ppid,args'],text=True)
assert not any('node ' in line and ('test/run.js' in line or 'test/test-cli-candidate-corpus.js' in line) for line in processes.splitlines()),processes
result=dict(exit=code,seconds=time.monotonic()-start,sourceSeals=len(source),changed=changed,intakeSeals=len(seals),gameFiles=39,companions=38,vfsFiles=39,ownedGuestProcesses=0,canonical=sha(repo/'build/wine-assembly.wasm'),consumer=command['wasmSha256'],corpus=(out/'corpus.log').read_text())
(out/'receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
