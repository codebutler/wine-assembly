# Recovery

This run reviews task/army-authority-startup-repair-oct21 at 3372225162a8e83e5a9d67c4d3c0740496f85da2.
Its tracked docs/reviews/army-authority-startup-repair-20261021.evidence.tgz
preserves the 57 producer evidence files; no binary build or asset staging is
needed to repeat the source review. The sibling independent evidence archive
preserves focused logs, controls and identity/seal receipts. Extract into a new
directory and verify SHA256SUMS.json. To replay ownership-controls.js, create
a repo subdirectory checked out at the candidate with lib/tools/src available.
Run the seven tests named in tests.json from that checkout. The controls modify
only its observer file temporarily and restore it in finally; use an isolated
checkout. Production runtime is not needed for these checks.

publication.json and repository messageboard record final exact pushed refs.
Coordinator owns bx_e8a7pw8v shutdown; do not resume or recreate it for this review.
