'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {spawnSync}=require('node:child_process');
const root=__dirname,repo=path.join(root,'repo');
const observer=path.join(repo,'tools/army-bltfast-observer.js');
const original=fs.readFileSync(observer,'utf8');
function run(name,args,env={}) {
  const r=spawnSync(process.execPath,args,{cwd:repo,env:{...process.env,NODE_OPTIONS:'',ARMY_BLTFAST_OUTPUT:'',...env},encoding:'utf8',timeout:30000});
  fs.writeFileSync(path.join(root,name+'.log'),r.stdout+r.stderr);
  return r;
}
// Explicit capture remains usable in an auxiliary worker even with an inherited
// output opt-in and foreign map. The explicit fixture supplies its own regions.
const script=`
const assert=require('node:assert/strict'),fs=require('node:fs');
const {Worker}=require('node:worker_threads');
const w=new Worker(\`
 const assert=require('node:assert/strict');
 const original=WebAssembly.instantiate;
 require('./tools/army-bltfast-observer.test.js');
 assert.equal(WebAssembly.instantiate,original);
\`,{eval:true,execArgv:['--require',require.resolve('./tools/army-bltfast-observer')],
env:{...process.env,ARMY_BLTFAST_OUTPUT:'intentionally-relative.json',WINE_REGION_MAP:'explicit-fixture-map'}});
w.on('error',e=>{console.error(e);process.exitCode=1});
w.on('exit',code=>{assert.equal(code,0);assert.equal(fs.existsSync('intentionally-relative.json'),false);console.log('PASS worker explicit capture and pixel/ownership rejection fixtures; no implicit wrapping/output')});
`;
assert.equal(run('worker-explicit-capture',['-e',script]).status,0);
const guard="process.env.ARMY_BLTFAST_OUTPUT && require('node:worker_threads').isMainThread";
assert.equal(original.split(guard).length,2);
try {
  for(const [name,replacement,expected] of [
    ['unguarded-negative','process.env.ARMY_BLTFAST_OUTPUT',/ETIMEDOUT/],
    ['disabled-main-negative','false',/not to be reference-equal|not equal|AssertionError/],
  ]) {
    fs.writeFileSync(observer,original.replace(guard,replacement));
    const r=run(name,['tools/army-bltfast-preload.test.js']);
    assert.equal(r.status,1,name);assert.match(r.stdout+r.stderr,expected);
  }
} finally {fs.writeFileSync(observer,original)}
assert.equal(run('restored-preload',['tools/army-bltfast-preload.test.js']).status,0);
console.log('PASS explicit auxiliary capture, unguarded and disabled-main rejecting mutations, restored preload');
