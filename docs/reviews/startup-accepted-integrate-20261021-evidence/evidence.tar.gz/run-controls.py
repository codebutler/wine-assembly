import json, os, pathlib, subprocess
out = pathlib.Path(__file__).resolve().parent
repo = out / 'repo'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
rows = []
def run(name, command, env=None, expected=0):
    assert os.statvfs(out).f_bavail * os.statvfs(out).f_frsize - 2*67108864 > 2285895680
    assert sum(p.stat().st_blocks*512 for p in out.rglob('*') if p.is_file()) < 67108864
    p = subprocess.run(command, cwd=repo, env={**os.environ, **(env or {})}, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (out / 'logs' / (name+'.log')).write_text(p.stdout)
    row = dict(name=name, command=command, env=env or {}, expected=expected, actual=p.returncode)
    if expected == 1:
        assert 'AssertionError' in p.stdout, (name, p.stdout[-1500:])
        assert 'mutation target' not in p.stdout and 'UNIMPLEMENTED FIXTURE' not in p.stdout, name
    rows.append(row)
    (out/'tests-controls.json').write_text(json.dumps(rows, indent=2))
    print(name, p.returncode, flush=True)
    assert p.returncode == expected, (name, p.stdout[-2000:])
repair = ['node','docs/reviews/startup-latch-valid-show-fix-20261020.js']
for mutation,probe in [('null','NULL HWND'),('early','failed CREATE'),('rollback','nested successful'),('commit','creation callback boundary')]:
    run('mutation-'+mutation, repair+['../mutation-'+mutation+'.json'], {'REVIEW_REV':head,'REVIEW_MUTATION':mutation,'REVIEW_PROBE':probe},1)
run('mutation-ownership',['node','../runners/independent.js','../mutation-ownership.json'],{'REVIEW_REV':head,'FINAL_MUTATION':'ownership','FINAL_PROBE':'saved HWND'},1)
for mutation in ['explicit','info','continuation','renderer','iconic','retval']:
    run('submitted-'+mutation,['node','docs/reviews/shell-startup-complete-path-fix-20261020.js'],{'STARTUP_MUTATION':mutation},1)
for name,probe in [('null','NULL HWND'),('nccreate','failed NCCREATE'),('create','failed CREATE')]:
    run('original-'+name,repair+['../original-'+name+'.json'],{'REVIEW_REV':'b09ba2e350bf8789210c8bf6ad2fa3299b15045b','REVIEW_PROBE':probe},1)
for name,probe in [('dialog','dialog-marker'),('nested','nested hidden'),('removed','removed target')]:
    run('baseline-'+name,repair+['../baseline-'+name+'.json'],{'REVIEW_REV':'8bcd437fa4852417b13d375e54e07280621a161a','REVIEW_PROBE':probe})
run('environment-final',['node','../runners/environment.js','../env-results'],{'WINE_NAMED_EVENT_ENDPOINT':'{"integrationFixture":true}'})
run('region-map',['node','tools/gen-region-map.js','--check'])
run('whitespace',['git','diff','--check','4261fd93'])
