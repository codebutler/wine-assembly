const fs=require('fs'),api=require('./file-api'),cp=require('child_process'),assert=require('assert/strict'),crypto=require('crypto');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
 const base='/home/user/army-current-main',out=__dirname+'/provenance';fs.mkdirSync(out,{recursive:true});
 for(const [remote,name] of [['repo/build/wine-assembly.wasm','wine-assembly.wasm'],['repaired-evidence/build.log','build.log'],['repaired-evidence/build.exit','build.exit'],['repaired-evidence/source-manifest.json','build-source-manifest.json'],['support-gameplay-evidence/original-manifest.json','original-manifest.json']])fs.writeFileSync(out+'/'+name,await api.download(base+'/'+remote));
 const integrated=JSON.parse(fs.readFileSync(__dirname+'/integrated-gameplay-scroll-evidence/before-identity.json'));
 const source=JSON.parse(fs.readFileSync(out+'/build-source-manifest.json'));
 const current=new Map(integrated.sources.map(x=>[x.path,x]));
 const changed=source.files.filter(x=>current.get(x.path)?.sha256!==x.sha256).map(x=>x.path).sort();
 assert.deepEqual(changed,['docs/re-notes/army-men-observer-abi-fix-20261020.md','tools/army-bltfast-observer.js','tools/army-bltfast-preload.test.js']);
 const critical=source.files.filter(x=>/^(src\/|lib\/|vendor\/|test\/run\.js$|tools\/build|package.*json$)/.test(x.path));
 for(const x of critical)assert.equal(current.get(x.path).sha256,x.sha256,x.path);
 const rows=cp.execFileSync('git',['ls-tree','-r','c740f914e27395829deb9dbc0f2a3fe5762a2bdf'],{encoding:'utf8'}).trim().split('\n');
 for(const row of rows){const [header,path]=row.split('\t');assert.equal(current.get(path).gitBlob,header.split(' ')[2],path);}
 const wasm=fs.readFileSync(out+'/wine-assembly.wasm');assert.equal(wasm.length,1878508);assert.equal(sha(wasm),integrated.moduleSha256);
 const result={buildSource:source.revision,integrated:integrated.head,trackedIdentities:rows.length,criticalUnchanged:critical.length,changedSinceBuild:changed,moduleSha256:sha(wasm),moduleBytes:wasm.length,freshBuild:false,originalFilesVerified:integrated.originals};
 fs.writeFileSync(__dirname+'/provenance-verification.json',JSON.stringify(result,null,2));console.log(result);
})();
