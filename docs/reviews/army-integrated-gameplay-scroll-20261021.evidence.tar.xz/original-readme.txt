Army Men(TM) Demo
July 1998

You can find the full version of Army Men at your favorite PC game retailer.

The full version contains: 
- 28 action-soaked missions in 3 different terrains (Bayou, Desert, and Alpine)
- Multiplayer support for up to 4 players using: Internet, LAN, Modem or Serial 
Connection (You can also compete on HEAT.net or Mplayer.com)
- Tanks, Jeeps, Halftracks and Cargo Trucks
- Airstrikes, paratroop drops and air reconnaissance
- Stunning 3D graphics mimicking the physics of plastic
- Tons of destructive weapons including mortars, machine guns, grenades and bazookas

We recommend playing the Boot Camp before the actual missions. This will help 
you become familiar with the controls and weapons.

SARGE AND VEHICLE CONTROLS

Basic Movement and Firing
Numpad 8 = Move Forward, get up from kneel and prone.
Numpad 2 = Move Back
Numpad 4 = Turn Left
Numpad 6 = Turn Right
Space Bar or left click = Fire (Hold down to aim, release to fire, except auto rifle and 
flame thrower)

Weapons/Items 
F8 or D = Drop Current Selected Weapon
Keyboard 1 = Select first weapon
Keyboard 2 = Select second weapon
Keyboard 3 = Select third weapon or item 
Right Click = Toggles through weapons

Additional Vehicle Controls
F4 or E = Enter / Exit Vehicle
Z  = Turn Turret Left
X  = Turn Turret Right
Shift = Half Speed

Additional Sarge Controls.
Numpad 5 = Go down to kneel and prone
Numpad  7  = Roll Left
Numpad  9  = Roll Right
Numpad / = Dive
Shift = Walk

Scroll Mode
Enter = Scroll map and brings up free floating cursor
Enter = Return to Sarge Controls.
Left click on dash map = Transfers view to location

Ordering Squads
Tab = Toggle through squads
F1 = Order squad to Follow
F2 = Puts squad on Attack.  Scroll map and press �Space Bar� or left click to place
F3 = Puts squad on Defend.  Scroll map and press �Space Bar� or left click to place

F9 = Command squad to Attack Now at their current location
F10 = Command squad to Defend Now at their current location

Enter   = Return to Sarge control without giving order

Air Support
F5 = Scroll Map and press �Space Bar� or left click to place Air Strike
F6 = Scroll Map and press �Space Bar� or left click to place Paratroop Drop
F7 = Air Reconnaissance 

F11 = Recall Mission and pause game  
F12 = Bring up map
Esc = Options window and pause game


STRATEGIES

Enemy Mines
Pick up the crates in the camp area. Press F1 to order the squad to follow Sarge, and 
travel directly east. Eliminate the first rifleman you come across standing on top of a 
butte plateau. Put your troops on defend and walk through the mine shaft in this area 
and kill the grenadier on the other side. Pick up the autorifle and the grenade box. Then, 
go back out of the mine and head south until you find another mine. Drop anything you may 
have in slot #3 (you should have explosives), and go inside. You will find a mine sweeper. 
Select the sweeper, and head south, and then east, and then north through a minefield. When 
you see the Blue Spy, switch to your rifle and start firing. A Tan flamethrower will charge 
you so make sure to kill him. Then, kill the spy and get his note. 

Ghost Train
After grabbing the note, quickly head into the Tan camp and grab the health power up 
before going back around to the mine where you found the sweeper. Drop the sweeper, 
and pick up the explosives you had left there and head north west to the train bridge. Use 
an explosive or a bazooka to destroy the train bridge in the northwest corner of the map. 
Then go to the mine in sector F,2 and collect a flame thrower. Go to the train station and 
clean out the train station of all Tan. You will want to approach from the East and kill the 
first Tan Bazookaman who appears as you get to the station. After killing all the other 
soldiers, find the Tan soldier in sector C,1. He has the key, but he is surrounded by 
mines. First, shoot him, then get the Minesweeper to clear the mines. Collect the key to 
win.


Copyright 1998 The 3DO Company.  All rights reserved.
Army Men, 3DO, and their respective logos, are trademarks or registered trademarks
of The 3DO Company in the U.S. and/or other countries.  All other trademarks belong
to their respective owners.
