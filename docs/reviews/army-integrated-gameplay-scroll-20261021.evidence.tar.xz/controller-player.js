const fs=require('fs'),cp=require('child_process');
const root='/home/user/army-current-main/repo',out='/home/user/army-current-main/integrated-gameplay-scroll-evidence/player',vfs='/home/user/army-current-main/vfs';
fs.mkdirSync(out);fs.copyFileSync('/home/user/army-current-main/support-gameplay-evidence/registry.json',out+'/registry.json');
const args=['test/run.js',
 '--exe='+vfs+'/program files/the 3do company/army men demo/armymendemo.exe',
 '--exe-guest-path=C:\\Program Files\\The 3DO Company\\Army Men Demo\\ArmyMenDemo.exe',
 '--cwd=C:\\Program Files\\The 3DO Company\\Army Men Demo',
 '--vfs-tree='+vfs,'--reg-import='+out+'/registry.json','--no-build',
 '--wasm='+root+'/build/wine-assembly.wasm','--quiet-api','--no-close','--no-threads',
 '--batch-size=200000','--max-batches=960','--max-seconds=90','--trace-input',
 '--png='+out+'/final.png',
 '--input='+[
  '200:png:'+out+'/menu.png',
  '279:click:320:180',
  '450:png:'+out+'/bootcamp.png',
  '500:keydown:13',
  '501:keyup:13',
  '670:png:'+out+'/baseline.png',
  '674:keydown:102',
  '690:png:'+out+'/scroll-held.png',
  '705:png:'+out+'/scroll-last-held.png',
  '706:keyup:102',
  '713:png:'+out+'/scroll-released.png',
  '735:png:'+out+'/player-before.png',
  '740:keydown:104',
  '746:png:'+out+'/player-move-held.png',
  '755:keyup:104',
  '765:png:'+out+'/player-move-released.png',
  '780:keydown:32',
  '785:png:'+out+'/player-aim.png',
  '795:keyup:32',
  '796:png:'+out+'/player-fire-release.png',
  '798:png:'+out+'/player-fire-798.png',
  '800:png:'+out+'/player-fire-800.png',
  '805:png:'+out+'/player-fire-805.png',
  '825:png:'+out+'/player-after.png',
  '850:keydown:13',
  '851:keyup:13',
  '875:png:'+out+'/camera-before.png',
  '880:keydown:102',
  '886:png:'+out+'/camera-held.png',
  '895:png:'+out+'/camera-held-895.png',
  '912:keyup:102',
  '925:png:'+out+'/camera-released.png',
  '950:png:'+out+'/camera-settled.png'
 ].join(',')];
const env=Object.fromEntries(Object.entries(process.env).filter(([k])=>!(/^(WA_|WINE_|ARMY_)/.test(k)||['NODE_OPTIONS','NODE_PATH'].includes(k))));

fs.writeFileSync(out+'/launch.json',JSON.stringify({at:new Date().toISOString(),root,args,observer:false,inputRoute:'Corrected from default capture mode evidence: retain initial route; no Enter before Numpad8 740-755; Space780-795; Enter850 scroll; Numpad6 880-912' },null,2));
const fd=fs.openSync(out+'/output.log','wx'),child=cp.spawn(process.execPath,args,{cwd:root,env,stdio:['ignore','pipe','pipe']});
let bytes=0,reason=null;
const recv=b=>{bytes+=b.length;if(bytes<=4194304)fs.writeSync(fd,b);else if(!reason){reason='4MiB output cap';child.kill('SIGKILL');}};
child.stdout.on('data',recv);child.stderr.on('data',recv);
const timer=setTimeout(()=>{reason='controller 90s deadline';child.kill('SIGTERM');setTimeout(()=>child.kill('SIGKILL'),3000).unref();},90000);
child.on('close',(code,signal)=>{clearTimeout(timer);fs.closeSync(fd);fs.writeFileSync(out+'/exit.json',JSON.stringify({at:new Date().toISOString(),code,signal,reason,bytes}));console.log({code,signal,reason,bytes});process.exitCode=code??1;});
