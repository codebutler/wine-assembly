const fs=require('fs'),api=require('./file-api');
(async()=>{
const base='/home/user/army-current-main';
await api.upload(base+'/integrated-check.js',fs.readFileSync(__dirname+'/remote-check.js'));
console.log(api.exec(['node',base+'/integrated-check.js','old'],'old-identity-receipt'));
await api.upload(base+'/integrated.bundle',fs.readFileSync(__dirname+'/integrated.bundle'));
console.log(api.exec(['git','-C',base+'/repo','fetch',base+'/integrated.bundle','refs/heads/task/army-integrated-gameplay-scroll-oct21'],'fetch-receipt'));
console.log(api.exec(['git','-C',base+'/repo','reset','--hard','c740f914e27395829deb9dbc0f2a3fe5762a2bdf'],'reconcile-receipt'));
console.log(api.exec(['node',base+'/integrated-check.js','before'],'before-identity-receipt'));
fs.writeFileSync(__dirname+'/original-readme.txt',await api.download(base+'/vfs/program files/the 3do company/army men demo/readme.txt'));
})();
