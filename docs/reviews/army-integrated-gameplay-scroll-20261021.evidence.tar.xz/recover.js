'use strict';
const fs=require('fs'),api=require('./file-api');
(async()=>{
 console.log(api.exec(['node','/home/user/army-current-main/integrated-check.js','after'],'after-identity-receipt',30));
 console.log(api.exec(['node','-e',`
const fs=require('fs'),cp=require('child_process'),crypto=require('crypto');
const out='/home/user/army-current-main/integrated-gameplay-scroll-evidence';
fs.writeFileSync(out+'/processes-after.txt',cp.execFileSync('ps',['-eo','pid,args']));
const rows=[];function walk(d,prefix=''){for(const e of fs.readdirSync(d,{withFileTypes:true})){if(e.isDirectory())walk(d+'/'+e.name,prefix+e.name+'/');else if(e.name!=='SHA256SUMS.json'){const b=fs.readFileSync(d+'/'+e.name);rows.push({path:prefix+e.name,bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex')});}}}
walk(out);fs.writeFileSync(out+'/SHA256SUMS.json',JSON.stringify(rows,null,2));console.log({artifacts:rows.length,bytes:rows.reduce((n,r)=>n+r.bytes,0)});
`],'seals-receipt',15));
 console.log(api.exec(['tar','-czf','/home/user/army-current-main/integrated-gameplay-scroll-evidence.tgz','-C','/home/user/army-current-main','integrated-gameplay-scroll-evidence'],'archive-receipt',30));
 fs.writeFileSync(__dirname+'/remote-evidence.tgz',await api.download('/home/user/army-current-main/integrated-gameplay-scroll-evidence.tgz'));
})();
