const fs=require('fs'),api=require('./file-api');
(async()=>{await api.upload('/home/user/army-current-main/integrated-controller.js',fs.readFileSync(__dirname+'/controller.js'));console.log(api.exec(['node','/home/user/army-current-main/integrated-controller.js'],'runtime-receipt',100));})();
