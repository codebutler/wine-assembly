const fs=require('fs'),cp=require('child_process');
const root='/home/user/army-current-main/repo',out='/home/user/army-current-main/integrated-gameplay-scroll-evidence/default',vfs='/home/user/army-current-main/vfs';
fs.mkdirSync(out);fs.copyFileSync('/home/user/army-current-main/support-gameplay-evidence/registry.json',out+'/registry.json');
const args=['test/run.js',
 '--exe='+vfs+'/program files/the 3do company/army men demo/armymendemo.exe',
 '--exe-guest-path=C:\\Program Files\\The 3DO Company\\Army Men Demo\\ArmyMenDemo.exe',
 '--cwd=C:\\Program Files\\The 3DO Company\\Army Men Demo',
 '--vfs-tree='+vfs,'--reg-import='+out+'/registry.json','--no-build',
 '--wasm='+root+'/build/wine-assembly.wasm','--quiet-api','--no-close','--no-threads',
 '--batch-size=200000','--max-batches=1030','--max-seconds=90','--trace-input',
 '--png='+out+'/final.png',
 '--input='+[
  '200:png:'+out+'/menu.png',
  '279:click:320:180',
  '450:png:'+out+'/bootcamp.png',
  '500:keydown:13',
  '501:keyup:13',
  '670:png:'+out+'/baseline.png',
  '674:keydown:102',
  '690:png:'+out+'/scroll-held.png',
  '705:png:'+out+'/scroll-last-held.png',
  '706:keyup:102',
  '713:png:'+out+'/scroll-released.png',
  '735:png:'+out+'/scroll-settled.png',
  '740:keydown:13',
  '741:keyup:13',
  '760:png:'+out+'/sarge-before.png',
  '770:keydown:104',
  '785:png:'+out+'/move-held.png',
  '805:keyup:104',
  '815:png:'+out+'/move-released.png',
  '830:keydown:32',
  '840:png:'+out+'/aim-held.png',
  '850:keyup:32',
  '851:png:'+out+'/fire-release.png',
  '860:png:'+out+'/fire-after.png',
  '880:png:'+out+'/player-settled.png',
  '900:keydown:13',
  '901:keyup:13',
  '925:png:'+out+'/camera-before.png',
  '930:keydown:102',
  '946:png:'+out+'/camera-held.png',
  '961:png:'+out+'/camera-last-held.png',
  '962:keyup:102',
  '975:png:'+out+'/camera-released.png',
  '1020:png:'+out+'/camera-settled.png'
 ].join(',')];
const env=Object.fromEntries(Object.entries(process.env).filter(([k])=>!(/^(WA_|WINE_|ARMY_)/.test(k)||['NODE_OPTIONS','NODE_PATH'].includes(k))));

fs.writeFileSync(out+'/launch.json',JSON.stringify({at:new Date().toISOString(),root,args,observer:false,inputRoute:'Prior Boot Camp/camera route retained; Enter740 return Sarge controls; Numpad8 770-805 movement; Space830-850 aim/fire; Enter900 scroll mode; Numpad6 930-962 controlled scroll' },null,2));
const fd=fs.openSync(out+'/output.log','wx'),child=cp.spawn(process.execPath,args,{cwd:root,env,stdio:['ignore','pipe','pipe']});
let bytes=0,reason=null;
const recv=b=>{bytes+=b.length;if(bytes<=4194304)fs.writeSync(fd,b);else if(!reason){reason='4MiB output cap';child.kill('SIGKILL');}};
child.stdout.on('data',recv);child.stderr.on('data',recv);
const timer=setTimeout(()=>{reason='controller 90s deadline';child.kill('SIGTERM');setTimeout(()=>child.kill('SIGKILL'),3000).unref();},90000);
child.on('close',(code,signal)=>{clearTimeout(timer);fs.closeSync(fd);fs.writeFileSync(out+'/exit.json',JSON.stringify({at:new Date().toISOString(),code,signal,reason,bytes}));console.log({code,signal,reason,bytes});process.exitCode=code??1;});
