# Recovery

Extract `docs/reviews/army-integrated-gameplay-scroll-20261021.evidence.tar.xz`
from the task branch into an empty directory. Run `python3 verify.py` there.
All remote screenshots, logs, three source inventories and53 runtime seals are
included directly (no nested gzip required), along with actual canonical WASM,
prior canonical build log/exit/source inventory, original asset manifest,
original readme, controller/API scripts and validation receipts. Local duplicate
gzip was removed only after every archived member matched extracted bytes.

Source is exact Git main c740f914e27395829deb9dbc0f2a3fe5762a2bdf; fetch that
commit from origin. No patch is required. The old state30a2 plus accepted
observer/test files is separately inventoried. Reuse included module only after
verifying recorded source/module SHA256; it was not rebuilt for this task.

Assets are not committed. The retained local originals are under
scratch/runs/20261019-army-men-authorized-install-buffer/final-vfs/; original
419 files and DLL support hashes are recorded in provenance/original-manifest.json
and the before/after identity receipts. Original package acquisition/installation
recipe is in docs/re-notes/army-men-authorized-recovery-20261019.md and related
acquisition notes at the tested source commit. Do not substitute source rebuilds
or generated placeholders. Do not reaccept licences; existing acceptance remains.

Assigned remote source is /home/user/army-current-main/repo; original VFS is
/home/user/army-current-main/vfs; evidence is
/home/user/army-current-main/integrated-gameplay-scroll-evidence and sibling.tgz.
The file-api.js helper can recover bytes before box expiry, using existing
credentials without printing them. No secret is included in these artifacts.
Controller output directories use exclusive creation: do not replay in place.
Coordinator retains lifecycle ownership; leave bx_e8a7pw8v running, expiry
2026-10-21T12:21:46.313Z. Do not resume, create or stop a box by default.
