const fs=require('fs'),api=require('./file-api');
(async()=>{await api.upload('/home/user/army-current-main/integrated-player-controller.js',fs.readFileSync(__dirname+'/controller-player.js'));console.log(api.exec(['node','/home/user/army-current-main/integrated-player-controller.js'],'player-runtime-receipt',100));})();
