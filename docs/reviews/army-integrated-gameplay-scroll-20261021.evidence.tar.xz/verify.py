import json,hashlib,tarfile,io
from pathlib import Path
p=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
e=p/'integrated-gameplay-scroll-evidence'
seals=json.loads((e/'SHA256SUMS.json').read_text())
for r in seals:
 b=(e/r['path']).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256'],r['path']
for phase in ['before','after']:
 x=json.loads((e/(phase+'-identity.json')).read_text());assert x['head']=='c740f914e27395829deb9dbc0f2a3fe5762a2bdf' and not x['changed'] and x['originals']==419 and len(x['sources'])==7303
before=json.loads((e/'before-identity.json').read_text());after=json.loads((e/'after-identity.json').read_text());assert before['sources']==after['sources']
build=json.loads((p/'provenance/build-source-manifest.json').read_text());current={r['path']:r for r in before['sources']}
deltas=[r['path'] for r in build['files'] if current[r['path']]['sha256']!=r['sha256']]
assert sorted(deltas)==['docs/re-notes/army-men-observer-abi-fix-20261020.md','tools/army-bltfast-observer.js','tools/army-bltfast-preload.test.js']
wasm=(p/'provenance/wine-assembly.wasm').read_bytes();assert len(wasm)==1878508 and sha(wasm)==before['moduleSha256']=='728e1de80ec20a284fc41b339895ee8ac29f16e4ded83325b27576cfacd4466c'
for run,batches in [('default',1030),('player',960)]:
 d=e/run;ex=json.loads((d/'exit.json').read_text());assert ex['code']==0 and ex['reason'] is None and ex['signal'] is None and ex['bytes']<4194304
 launch=json.loads((d/'launch.json').read_text());assert launch['observer'] is False and '--require' not in launch['args'] and '--max-seconds=90' in launch['args']
 log=(d/'output.log').read_text();assert f'{batches} batches' in log
 for event in next(a for a in launch['args'] if a.startswith('--input=')).split('=',1)[1].split(','):
  fields=event.split(':');batch,action=fields[:2]
  if action in ['keydown','keyup']:assert f'[input] {action} vk={fields[2]} at batch {batch}' in log
  if action=='png':assert (d/Path(':'.join(fields[2:])).name).exists()
assert all(x['identical'] for x in json.loads((p/'observer-comparison.json').read_text()))
# Before deleting the redundant downloaded gzip, require byte-for-byte extracted equality.
archive=p/'remote-evidence.tgz'
if archive.exists():
 with tarfile.open(archive,'r:gz') as tf:
  for m in tf.getmembers():
   if m.isfile():assert tf.extractfile(m).read()==(p/m.name).read_bytes(),m.name
outer=p/'SHA256SUMS.json'
if outer.exists():
 for r in json.loads(outer.read_text()):
  b=(p/r['path']).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256'],r['path']
print(json.dumps({'pass':True,'runtimeSeals':len(seals),'trackedSourceIdentities':7303,'originalAssetCount':419,'runs':2,'sourceAndModuleMatch':True}))
