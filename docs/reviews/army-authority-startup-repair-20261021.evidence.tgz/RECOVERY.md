# Recovery

Extract `docs/reviews/army-authority-startup-repair-20261021.evidence.tgz` from
the task branch into a fresh directory. Extract its `remote-evidence.tgz` there,
then run `python3 verify.py`. The outer archive contains scripts, baseline logs,
local focused logs and the untouched remote archive; it excludes the checkout
and duplicate extracted remote files. Original game and DLL binaries are not
committed. `candidate.json` seals the exact source candidate, and the nested
remote archive includes all7299 source hashes before/candidate/after plus the
module hash, original identity verification, screenshots and full guest log.

Remote staging is exact main30a2c3fb plus the two candidate files, NOT a remote
Git checkout at the candidate commit. Apply `candidate.patch` to that exact base
to recreate the source; do not apply again to the already patched remote tree.
Reuse the existing canonical module only with its recorded SHA256/provenance.
The prior canonical build receipt is the separately preserved
20261021-army-repaired-canonical-runtime report; this task did not rebuild.

Before box expiry, `file-api.js` can download
`/home/user/army-current-main/authority-startup-repair-evidence.tgz` from
`bx_e8a7pw8v`. Do not rerun stage.js/launch.js for evidence recovery. Run1 owns
exclusive paths, so a fresh assigned replay must choose new output paths.
The coordinator owns lifecycle; leave the box running and never resume it by
default. No asset packaging is needed. No credentials are stored in evidence;
the helper reads the existing local Boat credential only when explicitly run.
