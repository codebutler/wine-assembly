import hashlib, json
from pathlib import Path

root = Path(__file__).resolve().parent
remote = root / 'authority-startup-repair-evidence'
sha = lambda b: hashlib.sha256(b).hexdigest()
seals = json.loads((remote / 'SHA256SUMS.json').read_text())
for row in seals:
    p = remote / row['path']
    assert p.resolve().is_relative_to(remote.resolve())
    b = p.read_bytes()
    assert len(b) == row['bytes'] and sha(b) == row['sha256'], row['path']
candidate = json.loads((root / 'candidate.json').read_text())
before = json.loads((remote / 'before-identity.json').read_text())
after = json.loads((remote / 'after-identity.json').read_text())
assert before['changed'] == []
assert after['head'] == candidate['base'] == before['head']
assert set(after['changed']) == set(candidate['files'])
old = {r['path']: r for r in before['sources']}
assert len(old) == len(after['sources']) == 7299
for row in after['sources']:
    if row['path'] in candidate['files']:
        assert row['sha256'] == candidate['files'][row['path']]
    else:
        assert row == old[row['path']], row['path']
assert after['moduleSha256'] == before['moduleSha256'] == '728e1de80ec20a284fc41b339895ee8ac29f16e4ded83325b27576cfacd4466c'
assert after['moduleBytes'] == before['moduleBytes'] == 1878508
assert after['originals'] == before['originals'] == 419
assert after['resolved'] == before['resolved']
assert sha((remote / 'run1/registry.json').read_bytes()) == 'f9cb15d55aba37c096a4886b3c1968777281b40665f2d1e0281b127aa5745c6b'
assert all(r['exit'] == 0 for r in json.loads((remote / 'focused-tests.json').read_text()))
log = (remote / 'run1/output.log').read_text()
assert 'Calling DllMain at 0xa47fcb...\nDllMain returned, EAX=0x1' in log
assert 'ETIMEDOUT' not in log and 'DllMain trapped' not in log
for text in ['click 320,180 at batch 279', 'keydown vk=13 at batch 500',
             'keyup vk=13 at batch 501', 'keydown vk=102 at batch 674',
             'keyup vk=102 at batch 706', '750 batches in 12.099s']:
    assert text in log, text
exit = json.loads((remote / 'run1/exit.json').read_text())
assert exit['code'] == 0 and exit['signal'] is None and exit['reason'] is None
pair = json.loads((remote / 'run1/paired.json').read_text())
assert pair['accepted'] is True and len(pair['records']) == 8
assert not pair['observer']['errors'] and pair['observer']['pendingDepth'] == 0
for r in pair['records']:
    assert r['state'] == 'complete' and r['hresult'] == 0
    assert r['copyCheck'] == 'sampled-copy-matches' and len(r['samples']) == 9
    assert r['initialCorruption']['status'] == 'unknown'
    for s in r['samples']:
        assert s['sourcePre'] == s['destinationPost']
oldlogs = [(root / 'before' / ('run' + str(i) + '.log')).read_bytes() for i in [1,2]]
assert oldlogs[0] == oldlogs[1] and len(oldlogs[0]) == 4041
assert b'ETIMEDOUT' in oldlogs[0]
worker = json.loads((root / 'worker-error-before.json').read_text())
assert 'EEXIST' in worker['stdout'] and 'army-bltfast-observer.js:138' in worker['stdout']
print(json.dumps({'remoteSeals':len(seals),'sourceFiles':7299,'originals':419,
                  'oldMatchingFailures':2,'candidateExit':0,'sampledCalls':8,'verified':True}))
