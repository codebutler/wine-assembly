'use strict';
const fs=require('fs'),cp=require('child_process'),assert=require('assert/strict');
const root='/home/user/army-current-main/repo',out='/home/user/army-current-main/authority-startup-repair-evidence';
const results=[];
for(const test of ['tools/army-bltfast-preload.test.js','tools/army-bltfast-observer.test.js','tools/army-bltfast-captured-abi.test.js','tools/jig-owning-api-observer.test.js','tools/callback-ownership-census.js']){
 const r=cp.spawnSync(process.execPath,[test],{cwd:root,encoding:'utf8',timeout:30000});
 fs.writeFileSync(out+'/'+test.split('/').pop()+'.log',(r.stdout||'')+(r.stderr||''));
 results.push({test,exit:r.status,signal:r.signal,error:r.error?.message});
 fs.writeFileSync(out+'/focused-tests.json',JSON.stringify(results,null,2));
 assert.equal(r.status,0,test+'\n'+r.stdout+r.stderr);
}
console.log(JSON.stringify(results));
