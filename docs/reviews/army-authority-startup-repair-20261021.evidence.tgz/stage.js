'use strict';
const fs=require('fs'),crypto=require('crypto'),assert=require('assert/strict'),api=require('./file-api');
const root='/home/user/army-current-main/repo',out='/home/user/army-current-main/authority-startup-repair-evidence';
(async()=>{
 await api.upload('/home/user/army-current-main/authority-startup-check.js',fs.readFileSync(__dirname+'/remote-check.js'));
 console.log(api.exec(['node','/home/user/army-current-main/authority-startup-check.js','before'],'before-identity-receipt',30));
 const candidate={base:'30a2c3fb1b5c2bfa8a6b001d7394d5cf50df295d',commit:require('child_process').execFileSync('git',['rev-parse','HEAD'],{cwd:__dirname+'/repo',encoding:'utf8'}).trim(),files:{}};
 for(const p of ['tools/army-bltfast-observer.js','tools/army-bltfast-preload.test.js']) {
  const b=fs.readFileSync(__dirname+'/repo/'+p);candidate.files[p]=crypto.createHash('sha256').update(b).digest('hex');
  await api.upload(root+'/'+p,b);assert.deepEqual(await api.download(root+'/'+p),b);
 }
 fs.writeFileSync(__dirname+'/candidate.json',JSON.stringify(candidate,null,2));
 await api.upload(out+'/candidate.json',fs.readFileSync(__dirname+'/candidate.json'));
 console.log(api.exec(['node','/home/user/army-current-main/authority-startup-check.js','candidate'],'candidate-identity-receipt',30));
})();
