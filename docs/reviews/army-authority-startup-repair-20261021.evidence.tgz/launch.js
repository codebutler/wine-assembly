'use strict';
const fs=require('fs'),api=require('./file-api');
(async()=>{
 await api.upload('/home/user/army-current-main/authority-startup-tests.js',fs.readFileSync(__dirname+'/remote-tests.js'));
 console.log(api.exec(['node','/home/user/army-current-main/authority-startup-tests.js'],'focused-test-receipt',60));
 await api.upload('/home/user/army-current-main/authority-startup-controller.js',fs.readFileSync(__dirname+'/controller.js'));
 console.log(api.exec(['node','/home/user/army-current-main/authority-startup-controller.js'],'runtime-receipt',120));
})();
