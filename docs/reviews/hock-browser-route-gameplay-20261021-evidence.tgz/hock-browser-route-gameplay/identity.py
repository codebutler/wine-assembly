import pathlib,json,hashlib,subprocess
out=pathlib.Path('/home/user/hock-browser-route-gameplay');repo=pathlib.Path('/home/user/hock-registered-runtime/repo');base=repo.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected=json.loads((out/'expected-source.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()=='71bc4a6d07387c18725da334983d25c6290fed40'
diffs=subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines();assert set(diffs)==set(expected),diffs
for n,h in expected.items():assert sha(repo/n)==h,n
# The exact Git index is main; compare every tracked file to its blob, except
# the four locally sealed browser-registration files. No compile input changes.
rows=subprocess.check_output(['git','ls-files','-s','-z'],cwd=repo).split(b'\0');count=0
for row in rows:
 if not row:continue
 meta,name=row.split(b'\t');mode,oid,stage=meta.split();n=name.decode();p=repo/n
 if n in expected:continue
 data=p.readlink().as_posix().encode() if mode==b'120000' else p.read_bytes()
 actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 assert actual==oid.decode(),n;count+=1
seals=json.loads((base/'evidence/accepted-package-seals.json').read_text());fixture=repo/'test/binaries/candidates/hock-a-loogie-1995'
for n,h in seals.items():
 assert sha(base/'intake'/n)==h,n
 if n.startswith('game/'):assert sha(fixture/n)==h,n
inventory=json.loads((fixture/'.wine-assembly-browser.json').read_text());assert len(inventory['files'])==38
for f in inventory['files']:
 p=fixture/f['url'];assert sha(p)==seals[f['url']] and p.stat().st_size==f['size'] and f['vfsPath']=='c:\\'+p.name
wasm=sha(repo/'build/wine-assembly.wasm');assert wasm=='728e1de80ec20a284fc41b339895ee8ac29f16e4ded83325b27576cfacd4466c'
r={'base':'71bc4a6d07387c18725da334983d25c6290fed40','unchangedTrackedBlobs':count,'changed':expected,'intakeSeals':len(seals),'originalGameFiles':39,'companions':38,'wasmSha256':wasm,'manifestSha256':sha(fixture/'.wine-assembly-browser.json')}
(out/'identity-final.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
