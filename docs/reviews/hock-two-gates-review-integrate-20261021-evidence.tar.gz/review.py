import pathlib, subprocess as s, json, hashlib, os, time
run=pathlib.Path(__file__).resolve().parent
repo=run/'repo'
base='5b078c91d5cf6da5e337cda5e7665803c03c99e5'
records=json.loads((run/'review-tests.json').read_text()) if (run/'review-tests.json').exists() else []
def check(name,args,expected=0,needle=None,env=None):
    if any(r['command']==args and r['name']==name and r['accepted'] for r in records): return
    assert int(s.check_output(['du','-s','-B1',str(run)]).split()[0])+1000000<67108864
    assert os.statvfs(run).f_bavail*os.statvfs(run).f_frsize>2285895680
    p=s.run(args,cwd=repo,capture_output=True,text=True,env={**os.environ,**(env or {})},timeout=120)
    output=p.stdout+p.stderr
    (run/(name+'-'+str(len(records))+'.log')).write_text(output)
    ok=p.returncode==expected and (needle is None or needle in output)
    records.append(dict(name=name,command=args,exit=p.returncode,expected=expected,needle=needle,accepted=ok,env=env,log=name+'-'+str(len(records))+'.log'))
    (run/'review-tests.json').write_text(json.dumps(records,indent=2))
    print(name,p.returncode,ok,flush=True)
    assert ok,output[-3000:]
f=repo/'src/00-regions.wat'; fixed=f.read_bytes()
try:
    for name,owner,needle in [('original','$STARTUP_SHOW_STATE','does not define top-level $STARTUP_SHOW_STATE'),('indirect','$startup_info_init','no longer references $STARTUP_SHOW_STATE')]:
        f.write_bytes(fixed.replace(b'09a-handlers3-sync.wat:$startup_show_set',('09a-handlers3-sync.wat:'+owner).encode()))
        check('owner-reject-'+name,['node','tools/check-region-decls.js','--check-owners'],1,needle)
finally: f.write_bytes(fixed)
for args in [
 ['node','tools/check-region-decls.js','--check-owners'],
 ['node','tools/check-region-decls.js','--strict'],
 ['node','test/test-region-owner-ratchet.js'],
 ['node','tools/callback-ownership-census.js'],
 ['node','test/test-callback-ownership-census.js'],
 ['node','tools/check-wat-manifest.js'],
 ['node','tools/check-wat-fragments.js'],
 ['node','tools/wat-dup-census.js','--check'],
 ['node','tools/gen-region-map.js','--check'],
 ['node','tools/region-alloc.js','--shake-all'],
 ['node','tools/check-watx-provenance.js'],
 ['node','tools/esp-epilogue.js','--check'],
 ['node','tools/gen-layout-offsets.js','--check'],
 ['node','docs/reviews/shell-startup-complete-path-fix-20261020.js'],
 ['node','docs/reviews/startup-latch-valid-show-fix-20261020.js',str(run/'startup-latch.json')],
 ['node','../independent.js','../independent.json'],
 ['node','../validation.js'],
]: check(pathlib.Path(args[1]).stem,args,env={'REVIEW_REV':base})
# Unchanged-base behavior and exact original A/W failure, isolated and restored.
f=repo/'src/09a-handlers2-runtime.wat'; fixed=f.read_bytes()
try:
    f.write_bytes(s.check_output(['git','show',base+':src/09a-handlers2-runtime.wat'],cwd=repo))
    check('base-aw-reject',['node','tools/aw-census.js','--check'],1,'NEW DIVERGENT RegisterClassExA/W')
    check('base-contract',['node','docs/reviews/registerclass-aw-contract-20261021.js','.'])
finally: f.write_bytes(fixed)
check('combined-aw-restored',['node','tools/aw-census.js','--check'])
check('combined-callback-restored',['node','tools/callback-ownership-census.js'])
check('whitespace',['git','diff','--cached','--check'])
