'use strict';
const fs=require('fs'),cp=require('child_process'),assert=require('assert/strict'),crypto=require('crypto');
const {parseSource}=require('./repo/tools/watx');
const base='5b078c91d5cf6da5e337cda5e7665803c03c99e5';
const old=p=>cp.execFileSync('git',['show',base+':'+p],{cwd:__dirname+'/repo',encoding:'utf8',maxBuffer:16*1024*1024});
const now=p=>fs.readFileSync(__dirname+'/repo/'+p,'utf8');
const canonical=n=>Array.isArray(n)?n.slice(1).map(canonical):n;
const parse=s=>JSON.parse(JSON.stringify(parseSource(s).map(canonical)));
const helper=parse(now('src/09c0-window-table.wat')).find(n=>n[0]==='func'&&n[1]==='$class_table_register_data');
assert.deepEqual(helper,['func','$class_table_register_data',['param','$name_wa','i32'],['param','$wndclass_wa','i32'],['result','i32'],['call','$class_table_register_encoded',['local.get','$name_wa'],['local.get','$wndclass_wa'],['i32.const','0']]]);
let expansions=0;
function expand(n){
 if(!Array.isArray(n))return n;
 if(n[0]==='call'&&n[1]==='$class_table_register_data'){
  assert.equal(n.length,4);expansions++;
  return ['call','$class_table_register_encoded',n[2],n[3],['i32.const','0']];
 }
 return n.map(expand);
}
const p='src/09a-handlers2-runtime.wat';
assert.deepEqual(expand(parse(old(p))),parse(now(p))); assert.equal(expansions,2);
const region='src/00-regions.wat';
assert.equal(now(region),old(region).replace('09a-handlers3-sync.wat:$STARTUP_SHOW_STATE','09a-handlers3-sync.wat:$startup_show_set'));
const seals=[];
for(const p of cp.execFileSync('git',['ls-tree','-r','--name-only',base],{cwd:__dirname+'/repo',encoding:'utf8'}).trim().split('\n')){
 if(!p.startsWith('src/')&&!p.startsWith('lib/')&&!p.endsWith('.js'))continue;
 if(!fs.existsSync(__dirname+'/repo/'+p))continue;
 const a=old(p),b=now(p),sha=s=>crypto.createHash('sha256').update(s).digest('hex');
 if(a!==b)assert(['src/00-regions.wat','src/09a-handlers2-runtime.wat','test/test-aw-census.js','test/test-region-owner-ratchet.js'].includes(p),p);
 seals.push({path:p,base:sha(a),combined:sha(b)});
}
console.log(JSON.stringify({base,expansions,helperPureForwarder:true,argumentOrderPreserved:true,entireRuntimeASTEquivalent:true,ownerOnlyRegionDelta:true,seals},null,2));
