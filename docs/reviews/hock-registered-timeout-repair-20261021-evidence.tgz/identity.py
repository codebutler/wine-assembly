import pathlib,json,hashlib,subprocess
base=pathlib.Path('/home/user/hock-registered-runtime');repo=base/'repo';out=pathlib.Path('/home/user/hock-registered-timeout-repair/evidence')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((base/'evidence/source-sha256.json').read_text());changed={n:sha(repo/n) for n,h in old.items() if sha(repo/n)!=h}
expected={'test/candidate-corpus/manifest.json','test/test-cli-candidate-corpus.js','test/test-candidate-runner-launch.js','test/test-hock-a-loogie-local-registration.js'}
assert set(changed)==expected,changed
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()=='d4ba733fb0d1c9e6d67ff0db715a5c0535307e6f'
seals=json.loads((base/'evidence/accepted-package-seals.json').read_text());fixture=repo/'test/binaries/candidates/hock-a-loogie-1995'
for n,h in seals.items():
 assert sha(base/'intake'/n)==h,n
 if n.startswith('game/'):assert sha(fixture/n)==h,n
inventory=json.loads((fixture/'.wine-assembly-browser.json').read_text());assert len(inventory['files'])==38
for f in inventory['files']:
 p=fixture/f['url'];assert f['vfsPath']=='c:\\'+p.name and f['size']==p.stat().st_size and sha(p)==seals[f['url']]
for n in ['registered-fixed','registered-negative','registered-final','registered-capture']:
 d=out/n;argv=json.loads((d/'actual-child-command.json').read_text());vfs=json.loads((d/'actual-vfs-resolution.json').read_text())
 assert argv['wasmSha256']=='a5972cbaf915aa1d155b301da5fae1c80298b2be381034945c7e58cc81e02f72'
 assert len(vfs['files'])==39
 for f in vfs['files']:assert f['sha256']==sha(pathlib.Path(f['hostPath']))==seals['game/'+f['guestPath']]
assert sha(repo/'build/wine-assembly.wasm')=='728e1de80ec20a284fc41b339895ee8ac29f16e4ded83325b27576cfacd4466c'
assert sha(repo/'build/wine-assembly.compat.wasm')=='25519647def1c2a25f505a81743d21dec55472ede8780f809edf09b6bb231018'
previous=json.loads((base/'evidence/SHA256SUMS.json').read_text())
for n,h in previous.items():assert sha(base/'evidence'/n)==h,n
(out/'identity.json').write_text(json.dumps(dict(base='d4ba733fb0d1c9e6d67ff0db715a5c0535307e6f',trackedChecked=len(old),changed=changed,originalIntakeSeals=len(seals),originalGameFiles=39,companions=38,registeredVfsFiles=39,priorEvidenceSeals=len(previous),canonical=sha(repo/'build/wine-assembly.wasm'),compat=sha(repo/'build/wine-assembly.compat.wasm')),indent=2))
print('PASS exact changed source set, all unchanged source, original payload, registered VFS/module identity, prior evidence intact')
