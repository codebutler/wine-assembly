import subprocess,pathlib,time,json,os,signal
repo=pathlib.Path('/home/user/hock-registered-runtime/repo');out=pathlib.Path('/home/user/hock-registered-timeout-repair/evidence')
manifest=repo/'test/candidate-corpus/manifest.json';fixed=manifest.read_bytes()
for name,negative,bound in [('registered-fixed',False,75),('registered-negative',True,135)]:
 d=out/name;d.mkdir();env=dict(os.environ,NODE_OPTIONS='--require=/home/user/hock-registered-timeout-repair/observe.cjs',HOCK_OBSERVE_DIR=str(d))
 if negative:
  data=json.loads(fixed);next(c for c in data['candidates'] if c['id']=='hock-a-loogie-1995')['cli']['batchSize']=100000
  manifest.write_text(json.dumps(data,indent=2)+'\n')
 args=['node','test/test-cli-candidate-corpus.js','--id=hock-a-loogie-1995','--strict'];start=time.monotonic();killed=False
 try:
  with (d/'corpus.log').open('w') as log:
   p=subprocess.Popen(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=p.wait(timeout=bound)
   except subprocess.TimeoutExpired:killed=True;os.killpg(p.pid,signal.SIGKILL);code=p.wait()
  (d/'receipt.json').write_text(json.dumps(dict(argv=args,exit=code,outerHardKilled=killed,seconds=time.monotonic()-start,negativeControl=negative),indent=2));print(name,code,time.monotonic()-start,flush=True)
 finally:manifest.write_bytes(fixed)
