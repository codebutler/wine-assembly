set -eu
python3 /home/user/hock-registered-timeout-repair/identity.py
cd /home/user/hock-registered-timeout-repair
cp repair.patch evidence/repair-v1.patch
cp matrix.py replay.py replay-final.py observe.cjs observe-v2.cjs identity.py evidence/
python3 - <<'INNER'
import pathlib,json,hashlib
r=pathlib.Path('evidence');s={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(r.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.json'}
(r/'SHA256SUMS.json').write_text(json.dumps(s,indent=2))
print('sealed',len(s),'files')
INNER
tar czf evidence.tgz evidence
sha256sum evidence.tgz
ps -eo pid,ppid,args | grep -E '[n]ode .*test/(run|test-cli-candidate-corpus).js' || true
