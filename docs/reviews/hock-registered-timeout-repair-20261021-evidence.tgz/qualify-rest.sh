set -eu
cd /home/user/hock-registered-runtime/repo
out=/home/user/hock-registered-timeout-repair/evidence
node test/test-hock-a-loogie-local-registration.js > "$out/fixed-hock-metadata.log" 2>&1
node test/test-candidate-cli-silver-launch.js > "$out/silver-regression.log" 2>&1
bash tools/build.sh > "$out/build.log" 2>&1
sha256sum build/wine-assembly*.wasm > "$out/modules-after.txt"
diff "$out/modules-before.txt" "$out/modules-after.txt"
git diff --check
printf 'ALL PASS; canonical modules unchanged\n'
