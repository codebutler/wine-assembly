set -eu
cd /home/user/hock-registered-runtime/repo
out=/home/user/hock-registered-timeout-repair/evidence
git diff --exit-code
sha256sum build/wine-assembly*.wasm > "$out/modules-before.txt"
git apply --include=test/test-hock-a-loogie-local-registration.js --include=test/test-candidate-runner-launch.js /home/user/hock-registered-timeout-repair/repair.patch
set +e
node test/test-hock-a-loogie-local-registration.js > "$out/baseline-hock-test.log" 2>&1
echo "$?" > "$out/baseline-hock-test.exit"
node test/test-candidate-runner-launch.js > "$out/baseline-termination-test.log" 2>&1
echo "$?" > "$out/baseline-termination-test.exit"
set -e
git apply -R --include=test/test-hock-a-loogie-local-registration.js --include=test/test-candidate-runner-launch.js /home/user/hock-registered-timeout-repair/repair.patch
git apply /home/user/hock-registered-timeout-repair/repair.patch
node test/test-candidate-runner-launch.js > "$out/fixed-termination-test.log" 2>&1
node test/test-hock-a-loogie-local-registration.js --intake=/home/user/hock-registered-runtime/intake > "$out/fixed-hock-test.log" 2>&1
node test/test-candidate-cli-silver-launch.js > "$out/silver-regression.log" 2>&1
bash tools/build.sh > "$out/build.log" 2>&1
sha256sum build/wine-assembly*.wasm > "$out/modules-after.txt"
diff "$out/modules-before.txt" "$out/modules-after.txt"
git diff --check
printf 'ALL PASS; canonical modules unchanged\n'
