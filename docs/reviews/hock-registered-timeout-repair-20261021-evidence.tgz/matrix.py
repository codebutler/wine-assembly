import subprocess,pathlib,time,json,os,signal
repo=pathlib.Path('/home/user/hock-registered-runtime/repo'); out=pathlib.Path('/home/user/hock-registered-timeout-repair/evidence')
common=['node','test/run.js','--exe='+str(repo/'test/binaries/candidates/hock-a-loogie-1995/game/BBLOOGIE.EXE'),'--wasm=/home/user/hock-registered-runtime/candidate-corpus-observed.wasm','--no-build','--no-close','--quiet-api','--quiet-blocks','--stuck-after=50','--vfs-include=**/*']
for name,extra,bound in [('small-batch',['--batch-size=1000','--max-batches=3000','--trace-batch-timing'],40),('real-clock-only',['--batch-size=100000','--max-batches=3000','--real-ticks','--max-seconds=20','--trace-batch-timing'],30),('prior-host-options',['--batch-size=1000','--max-batches=1000000','--real-ticks','--control-stdin','--max-seconds=20','--exe-guest-path=C:\\BBLOOGIE.EXE','--cwd=C:\\'],30)]:
 args=common+extra+['--png='+str(out/(name+'.png'))];start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  p=subprocess.Popen(args,cwd=repo,stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  killed=False
  try: code=p.wait(timeout=bound)
  except subprocess.TimeoutExpired: killed=True;os.killpg(p.pid,signal.SIGKILL);code=p.wait()
  finally: p.stdin.close()
 (out/(name+'.json')).write_text(json.dumps(dict(argv=args,exit=code,hardKilled=killed,seconds=time.monotonic()-start),indent=2)); print(name,code,time.monotonic()-start,flush=True)
