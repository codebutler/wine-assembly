import subprocess,pathlib,time,json,datetime,sys
base=pathlib.Path('/home/user/hock-scoring-runtime');r=base/sys.argv[1];r.mkdir(parents=True,exist_ok=False)
repo='/home/user/hock-final-size-canonical-runtime/repo'
args=['node','test/run.js','--no-build','--wasm='+repo+'/build/wine-assembly.wasm','--exe=/home/user/hock-final-size-canonical-runtime/intake/game/BBLOOGIE.EXE','--exe-guest-path=C:\\BBLOOGIE.EXE','--cwd=C:\\','--vfs-include=**/*','--quiet-api','--quiet-blocks','--max-seconds=72','--max-batches=1000000','--real-ticks','--control-stdin','--trace-input','--trace-input-dispatch','--png='+str(r/'final.png')]
events=[]
def cmd(t,s):events.append((t,{'cmd':s}))
def png(t,n):events.append((t,{'action':'png','path':str(r/(n+'.png'))}))
png(3,'start');cmd(4,'mousemove:124:386');cmd(5,'mousedown:124:386');cmd(5.25,'mouseup:124:386');png(8,'before');cmd(8.1,'dump-mem:0x41a018:52');cmd(9,'mousemove:320:250')
for i in range(36):
 t=10+i*1.55;duration=[.65,.8,.95][i%3]
 cmd(t,'mousemove:308:250');cmd(t+.03,'mousedown:308:250');cmd(t+.03+duration,'mouseup:308:250')
 if i%2==0:png(t+duration+.3,'shot-%02d'%i)
cmd(69,'dump-mem:0x41a018:52');png(70,'after')
events.sort(key=lambda x:x[0]);(r/'command.json').write_text(json.dumps(args,indent=2));start=time.monotonic();records=[]
with (r/'run.log').open('w') as log:
 p=subprocess.Popen(args,cwd=repo,stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT,text=True)
 for at,c in events:
  time.sleep(max(0,start+at-time.monotonic()))
  if p.poll() is not None:break
  c['id']=len(records)+1;p.stdin.write(json.dumps(c)+'\n');p.stdin.flush();records.append({'wallSeconds':time.monotonic()-start,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':c})
 p.stdin.close();rc=p.wait(timeout=20)
(r/'timings.json').write_text(json.dumps({'events':records,'exit':rc,'wallSeconds':time.monotonic()-start},indent=2));print('exit',rc);raise SystemExit(rc)
