# Hock registered CLI timeout repair recovery

Task branch task/hock-registered-timeout-repair-oct21; publication.json records
commit and independently verified remote ref. No main merge. Base d4ba733fb0d1c9e6d67ff0db715a5c0535307e6f.

Read docs/reviews/hock-registered-timeout-repair-20261021.md and extract adjacent
hock-registered-timeout-repair-20261021-evidence.tgz to an empty directory.
Verify SHA256SUMS.json and remote-evidence/SHA256SUMS.json. Final repair.patch
is the four-file production/test delta; repair-v1.patch is historical before
word-boundary correction. The branch also adds report/evidence and Hock notes.

Remote /home/user/hock-registered-runtime/repo retains exact base plus final
four-file patch, original fixture and dependencies. Reuse this staging; do not
reacquire or rebuild unchanged dependencies. Original evidence is unchanged at
/home/user/hock-registered-runtime/evidence. New scripts/evidence are under
/home/user/hock-registered-timeout-repair; final-repair.patch is the final patch.
No binaries are committed. Prior recovery recipe and report branch
(task/hock-registered-runtime-oct21 at cd2d15dce1339c57c0a863eb7eb7547746899979)
remain the original payload recovery source.

Registered-final is the actual no-argv-change acceptance command. Registered-capture
adds only --png via observe-v2.cjs; observer-options.json records effective argv.
Registered-fixed is the intermediate false-CRASH result, with an unpresented
read-only canvas capture (not acceptance). Registered-negative restores only
100000-block batches and proves timeout remains blocked. All scripts use new
output directories and process-group hard bounds; replay into NEW names, never
overwrite this evidence. Coordinator authorization is needed for new runtime work.

Final source/module identities are in remote-evidence/identity.json. Canonical
728e1de80ec20a284fc41b339895ee8ac29f16e4ded83325b27576cfacd4466c;
consumer a5972cbaf915aa1d155b301da5fae1c80298b2be381034945c7e58cc81e02f72.
The latter omits only canonical's trailing 37-byte layout custom section.
Final canonical build all gates passed, and final changed-source SHA256s match
this branch. No game bytes/memory/input/registry seeds/DLL substitutions changed.

Same bx_egnm3u4y is left RUNNING; assigned expiry 2026-10-21T10:44:02.530Z.
Coordinator owns shutdown. No stop/delete/resume/create is authorized by this
recipe; no owned guest processes remain at handoff. Local cap64MiB, free floor
2285895680 plus600MB reserve. Sparse repo borrows combined-integration objects;
remote branch is the durable backup, not that local alternate chain.
