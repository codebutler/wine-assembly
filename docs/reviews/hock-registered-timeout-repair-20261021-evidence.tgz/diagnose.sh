set -u
mkdir -p /home/user/hock-registered-timeout-repair/evidence
cd /home/user/hock-registered-runtime/repo
set +e
timeout -s KILL 30s node test/run.js --exe=test/binaries/candidates/hock-a-loogie-1995/game/BBLOOGIE.EXE --wasm=/home/user/hock-registered-runtime/candidate-corpus-observed.wasm --no-build --no-close --quiet-api --quiet-blocks --stuck-after=50 --max-batches=3000 --batch-size=100000 '--vfs-include=**/*' --trace-batch-timing --trace-sched --max-seconds=20 --png=/home/user/hock-registered-timeout-repair/evidence/diagnostic.png > /home/user/hock-registered-timeout-repair/evidence/diagnostic.log 2>&1
code=$?
echo "$code" > /home/user/hock-registered-timeout-repair/evidence/diagnostic.exit
tail -n 35 /home/user/hock-registered-timeout-repair/evidence/diagnostic.log
exit "$code"
