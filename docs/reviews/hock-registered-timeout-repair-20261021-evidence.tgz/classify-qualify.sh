set -eu
cd /home/user/hock-registered-runtime/repo
out=/home/user/hock-registered-timeout-repair/evidence
cp /home/user/hock-registered-timeout-repair/new-runner-test.js test/test-candidate-runner-launch.js
set +e
node test/test-candidate-runner-launch.js > "$out/baseline-classifier-test.log" 2>&1
code=$?
echo "$code" > "$out/baseline-classifier-test.exit"
set -e
test "$code" = 1
cp /home/user/hock-registered-timeout-repair/new-corpus.js test/test-cli-candidate-corpus.js
node test/test-candidate-runner-launch.js > "$out/final-runner-test.log" 2>&1
node test/test-hock-a-loogie-local-registration.js > "$out/final-hock-metadata.log" 2>&1
cp "$out/build.log" "$out/build-v1.log"
bash tools/build.sh > "$out/build.log" 2>&1
sha256sum build/wine-assembly*.wasm > "$out/modules-final.txt"
diff "$out/modules-before.txt" "$out/modules-final.txt"
git diff --check
echo 'PASS baseline rejection, fixed controls, all canonical build gates; modules unchanged'
