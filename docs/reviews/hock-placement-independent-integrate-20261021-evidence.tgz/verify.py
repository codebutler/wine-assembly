import subprocess,hashlib,json,tarfile,io,pathlib
root=pathlib.Path(__file__).resolve().parent;repo=root/'repo'
candidate='5d5e48d0d97be71f8f7c0dcc1596f5bea770d59d';base='7e5cf3535946e0a7bf42179b728a8471dc9f6b67'
def git(*a):return subprocess.check_output(['git','-C',str(repo),*a])
def sha(b):return hashlib.sha256(b).hexdigest()
data=git('show',candidate+':docs/reviews/hock-placement-loop-repair-20261021-evidence.tgz')
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
    files={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
seals=json.loads(files['SHA256SUMS.json'])
for f,h in seals.items():assert sha(files[f])==h,f
identity=json.loads(files['remote-evidence/identity.json'])
for key,f in [('source_seals_sha256','source-seals.json'),('package_seals_sha256','package-seals.json'),('patch_sha256','tested.patch')]:assert identity[key]==sha(files['remote-evidence/'+f])
sources=json.loads(files['remote-evidence/source-seals.json'])
# Stream Git blobs: no checkout/assets/full build. Each sealed remote source is
# compared to the candidate object, including paths outside our sparse scope.
proc=subprocess.Popen(['git','-C',str(repo),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for f,h in sources.items():
    proc.stdin.write((candidate+':'+f+'\n').encode());proc.stdin.flush()
    header=proc.stdout.readline().decode().split();assert len(header)==3,(f,header)
    n=int(header[2]);blob=proc.stdout.read(n);assert proc.stdout.read(1)==b'\n';assert sha(blob)==h,f
proc.stdin.close();assert proc.wait()==0
pkg=json.loads(files['remote-evidence/package-seals.json']);assert len([f for f in pkg if f.startswith('game/')])==39
parent=root.parent/'20261021-hock-accepted-canonical-runtime'
previous=json.loads((parent/'remote-evidence/package-seals.json').read_text()) if (parent/'remote-evidence/package-seals.json').exists() else None
if previous is not None:assert previous==pkg
assert git('rev-parse',base+'^{tree}').decode().strip()==identity['base_tree']
delta=git('diff','--name-only',base,candidate,'--','src','lib','tools','host.js','package.json','package-lock.json').decode().splitlines()
assert delta==['src/09a5b-handlers-window-late.wat'],delta
assert sha(git('show',candidate+':test/test-window-placement-client.js'))==identity['new_test_sha256']
assert git('diff',candidate,'HEAD','--','src','lib','tools','host.js','package.json','package-lock.json')==b''
result={'archiveSha256':sha(data),'sealedFiles':len(seals),'archiveFiles':len(files),'sourceFilesVerifiedAgainstCandidate':len(sources),'productionDelta':delta,'packageFiles':39,'packageMatchesParent':previous is not None,'identity':identity}
(root/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
