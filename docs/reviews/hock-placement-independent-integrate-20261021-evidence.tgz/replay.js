'use strict';
// Exact-source slices; no interpreter/full-tree compilation or game runtime.
const fs=require('fs'),cp=require('child_process'),vm=require('vm'),assert=require('assert/strict'),crypto=require('crypto');
const rev=process.env.REVIEW_REV||'5d5e48d0d97be71f8f7c0dcc1596f5bea770d59d', mutation=process.env.MUTATION||'';
const git=p=>cp.execFileSync('git',['show',rev+':'+p],{encoding:'utf8',maxBuffer:32*1024*1024});
const sha=s=>crypto.createHash('sha256').update(s).digest('hex'), inputs={};
function read(p){let s=git(p);inputs[p]=sha(s);
 if(p==='src/09a5b-handlers-window-late.wat'&&mutation){
  const start=s.indexOf('    ;; Placement changed the outer rect;'),end=s.indexOf('    ;; showCmd used',start),block=s.slice(start,end);assert(start>0&&end>start);
  if(mutation==='refresh-before-move'){s=s.slice(0,start)+s.slice(end);const at=s.indexOf('    ;; Move window to rcNormalPosition');s=s.slice(0,at)+block+s.slice(at);}
  else if(mutation==='omit-host-sync'){const at=block.indexOf('    (call $host_sync_window_client');s=s.slice(0,start)+block.slice(0,at)+s.slice(end);}
  else throw Error('unknown mutation');
 }return s;}
let machinery=git('docs/reviews/shell-startup-complete-path-fix-20261020.js');
const machinerySha=sha(machinery);machinery=machinery.slice(0,machinery.indexOf('async function main(){'));
const a=machinery.indexOf('function source(p) {'),b=machinery.indexOf('function form(s, at)');
machinery=machinery.slice(0,a)+'const source=readExact;\n'+machinery.slice(b);
machinery=machinery.replace("const BASE = '8bcd437fa4852417b13d375e54e07280621a161a';",`const BASE='${rev}';`);
machinery=machinery.replace("'defwndproc_do_nccalcsize',",'');
machinery=machinery.replace("const roots=['handle_CreateWindowExA','handle_ShowWindow','startup_info_init','handle_GetStartupInfoA','handle_GetStartupInfoW'];", "const roots=['handle_SetWindowPlacement','handle_GetClientRect','handle_ShowWindow','defwndproc_do_nccalcsize','wnd_table_set','client_rect_wh_packed','client_rect_get_l','client_rect_get_t','client_rect_get_r','client_rect_get_b','wnd_client_screen_x','wnd_client_screen_y'];");
machinery=machinery.replace("_computeClientRect:w=>{w.clientRect={x:0,y:0,w:w.w,h:w.h};},",'');
machinery=machinery.replace("'host_create_window','host_show_window'","'host_move_window','host_sync_window_client','host_create_window','host_show_window'");
// Renderer calls these canonical public export names.
machinery=machinery.replace("const access=[...gs]", "const clientExports=['l','t','r','b'].map(n=>`(export \"get_client_rect_${n}\" (func $client_rect_get_${n}))`).join('\\n');\n  const access=[...gs]");
machinery=machinery.replace("bodies.values(),exports,access]", "bodies.values(),exports,clientExports,access]");
machinery=machinery.replace('exports,clientExports,access]', 'exports,clientExports,\'(export \"get_client_rect_wh\" (func $client_rect_wh_packed))\',access]');
machinery+='\ninventory(); const c=compiler(); globalThis.api={funcs,selected,result,make:()=>fixture(c)};';
const context={require,console,process,readExact:read,WebAssembly,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,DataView,Buffer,setTimeout,clearTimeout,setImmediate};
vm.runInNewContext(machinery,context,{timeout:30000});const h=context.api;
function exercise(f){const e=f.e,d=new DataView(f.memory.buffer),reg=e.get_reg_base(),ptr=0x700000,out=ptr+64,stack=0x500000;
 const readClient=hwnd=>{d.setUint32(reg+16,stack,true);e.handle_GetClientRect(hwnd,out,0,0,0,0);return [0,4,8,12].map(i=>d.getInt32(out+i,true));};
 let count=0;const all=[];
 for(const [idx,style]of [0x10cf0000,0x90000000,0x00cf0000].entries()){
  const hwnd=0x10001+idx;e.wnd_table_set(hwnd,e.get_WNDPROC_BUILTIN());e.wnd_set_style(hwnd,style);
  f.renderer.createWindow(hwnd,style,11,17,400,300,'placement',0,{exports:e},f.memory);
  e.defwndproc_do_nccalcsize(hwnd);const initial=readClient(hwnd),ncW=400-initial[2],ncH=300-initial[3];
  const place=(x,y,w,ht)=>{
   const others=all.map(h=>[h,JSON.stringify(f.renderer.windows[h].clientRect),readClient(h)]);
   [44,0,1,0,0,0,0,x,y,x+w,y+ht].forEach((v,i)=>d.setInt32(ptr+i*4,v,true));d.setUint32(reg+16,stack,true);
   const traceStart=f.trace.length;
   e.handle_SetWindowPlacement(hwnd,ptr,0,0,0,0);
   assert.equal(d.getUint32(reg,true),1);assert.equal(d.getUint32(reg+16,true),stack+12,'stdcall');
   const trace=f.trace.slice(traceStart),move=trace.findIndex(x=>x.name==='host_move_window'),sync=trace.findIndex(x=>x.name==='host_sync_window_client'),show=trace.findIndex(x=>x.name==='host_show_window');
   if(!mutation&&rev!=='7e5cf3535946e0a7bf42179b728a8471dc9f6b67'){
    assert(move>=0&&sync>move,'host sync follows move');assert(show<0||show>sync,'first show follows sync');
    assert.equal(trace[sync].args[0],hwnd,'sync targets invocation HWND');
   }
   for(const [h,mirror,client]of others){assert.equal(JSON.stringify(f.renderer.windows[h].clientRect),mirror,'other window mirror unchanged');assert.deepEqual(readClient(h),client,'other window USER client unchanged');}
  };
  for(const [x,y,w,ht]of [[31,47,508,376],[59,61,287,193],[83,97,287,193],[83,97,287,193]]){
   place(x,y,w,ht);const win=f.renderer.windows[hwnd];assert.deepEqual([win.x,win.y,win.w,win.h],[x,y,w,ht]);
   assert.deepEqual(readClient(hwnd),[0,0,w-ncW,ht-ncH],'current placement client');
   assert.deepEqual([win.clientRect.w,win.clientRect.h],[w-ncW,ht-ncH],'host client mirror');
   assert.deepEqual([win.clientRect.x,win.clientRect.y],[x+e.client_rect_get_l(hwnd),y+e.client_rect_get_t(hwnd)],'host origin');count++;
  }
  const win=f.renderer.windows[hwnd],before=readClient(hwnd);place(101,103,211+win.w-before[2],233+win.h-before[3]);assert.deepEqual(readClient(hwnd).slice(2),[211,233]);assert(win.visible);count++;all.push(hwnd);
 }
 return {cases:count,crossWindowChecks:15,trace:f.trace};
}
let outcome;
try{for(let i=0;i<50;i++){try{outcome=exercise(h.make());break;}catch(e){const m=e.message.match(/^UNIMPLEMENTED FIXTURE DEPENDENCY (\w+)/);if(m&&h.funcs.has(m[1])&&!h.selected.has(m[1])){h.selected.add(m[1]);continue;}throw e;}}assert(outcome,'dependency expansion exhausted');console.log(JSON.stringify({status:'PASS',...outcome}));}
catch(e){outcome={error:e.stack};console.error(e.stack);process.exitCode=1;}
fs.writeFileSync(process.argv[2],JSON.stringify({rev,mutation,machinerySha,inputs,selected:[...h.selected],modules:h.result.modules,outcome},null,2));
