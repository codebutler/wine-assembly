# Independent placement acceptance — 2026-10-21

Review base: `7e5cf3535946e0a7bf42179b728a8471dc9f6b67`.
Candidate: `5d5e48d0d97be71f8f7c0dcc1596f5bea770d59d`.
Task branch: `task/hock-placement-independent-integrate-oct21`.

From a checkout containing those objects, run `node /path/to/replay.js out.json`.
Set `REVIEW_REV=7e5cf3535946e0a7bf42179b728a8471dc9f6b67` for the failing
base control; set `MUTATION=refresh-before-move` or `MUTATION=omit-host-sync`
for the other expected assertion failures. These mutations affect in-memory
source only. The driver reads exact Git objects, compiles selected production
functions and invokes actual host-window/renderer geometry. It never compiles
the interpreter or full tree. Notification/painting sinks and identity-address
adapters are explicitly recorded in its inherited fixture machinery.

`final-tests.json` lists exact passing local commands; `controls.json` lists
the three expected exit-1 commands. `verify.py` checks the candidate's sealed
archive and source hashes; its parent package comparison uses the original
accepted-runtime evidence directory. `verification.json` records the result.
Run scripts from the repository directory, not from the evidence directory.

The committed independent evidence archive contains these scripts, receipts,
source-slice inventories, trace, controls and logs. Candidate's separately
committed archive retains canonical build/runtime receipts and recovery.
No local full build, asset materialization or Boat operation is needed for
this independent replay. No lifecycle action is authorized by this recipe.

The canonical candidate WASM is SHA256
`eafeaa142c98fe60c489865c89a676c20afffe51002fe36799f42aa46d19ac2c`.
Its remote production sources match this integration exactly. The module was
not downloaded/rehashed locally. Runtime evidence is inherited and sealed,
not a new current-main run. Original selection only: no input, gameplay,
audio, rendering-completeness or Windows parity acceptance.
