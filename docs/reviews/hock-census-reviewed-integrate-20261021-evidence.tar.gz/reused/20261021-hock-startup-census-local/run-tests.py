import hashlib, json, os, pathlib, subprocess
out = pathlib.Path(__file__).resolve().parent
repo = out / 'repo'
rev = 'a33939583068231aaa7c3fc5155b87f3ec85c07b'
rows = []
def guard():
    allocated = sum(p.stat().st_blocks * 512 for p in out.rglob('*'))
    free = os.statvfs(out).f_bavail * os.statvfs(out).f_frsize
    assert allocated + 1048576 < 67108864 and free - 1048576 > 2285895680
def run(name, command, env=None, expected=0):
    guard()
    p = subprocess.run(command, cwd=repo, env={**os.environ, **(env or {})},
                       text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (out / (name + '.final.log')).write_text(p.stdout)
    rows.append(dict(name=name, command=command, env=env or {}, expected=expected, actual=p.returncode))
    (out / 'tests.json').write_text(json.dumps(rows, indent=2))
    print(name, p.returncode, flush=True)
    assert p.returncode == expected, p.stdout[-3000:]
    if expected:
        assert 'AssertionError' in p.stdout and 'mutation target' not in p.stdout and 'UNIMPLEMENTED FIXTURE' not in p.stdout, p.stdout[-3000:]

paths = sorted(p for p in repo.rglob('*') if p.is_file() and
               (p.relative_to(repo).parts[0] in ('src', 'lib') or
                (p.parent == repo and p.suffix == '.js')))
def seals(): return {str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
before = seals()
for p in paths:
    assert p.read_bytes() == subprocess.check_output(['git', 'show', rev + ':' + str(p.relative_to(repo))], cwd=repo)
(out / 'source-seals.json').write_text(json.dumps(before, indent=2))
run('census', ['node', 'tools/callback-ownership-census.js'])
run('census-controls', ['node', 'test/test-callback-ownership-census.js'])
run('submitted', ['node', 'docs/reviews/shell-startup-complete-path-fix-20261020.js'])
repair = ['node', 'docs/reviews/startup-latch-valid-show-fix-20261020.js']
run('repair', repair + ['../repair.json'], {'REVIEW_REV':rev})
run('independent', ['node', '../independent.js', '../independent.json'], {'REVIEW_REV':rev})
run('validation', ['node', '../validation.js'], {'WINE_NAMED_EVENT_ENDPOINT':'{"integrationFixture":true}'})
for mutation, probe in [('null','NULL HWND'), ('early','failed CREATE'), ('rollback','nested successful'), ('commit','creation callback boundary')]:
    run('reject-'+mutation, repair + ['../reject-'+mutation+'.json'],
        {'REVIEW_REV':rev, 'REVIEW_MUTATION':mutation, 'REVIEW_PROBE':probe}, 1)
run('reject-ownership', ['node','../independent.js','../reject-ownership.json'],
    {'REVIEW_REV':rev,'FINAL_MUTATION':'ownership','FINAL_PROBE':'saved HWND'},1)
for mutation in ['explicit','info','continuation','renderer','iconic','retval']:
    run('reject-'+mutation, ['node','docs/reviews/shell-startup-complete-path-fix-20261020.js'],
        {'STARTUP_MUTATION':mutation},1)
# Real CLI mutations supplement in-memory behavioral tests and assert the
# exact census diagnostic. Always restore bytes, even on an assertion failure.
controls = []
for file, old, new, name in [
    ('host.js', 'hidden: pipes || showCmd === 0, showCmd, beforeRun, onExit,',
     'hidden: pipes, beforeRun, onExit,', 'host-file'),
    ('src/09b-dispatch.wat', '(call $startup_create_show\n              (call $gl32 (i32.add (i32.load offset=16 (global.get $reg_base)) (i32.const 8))))',
     '(call $startup_create_show (global.get $createwnd_saved_hwnd))', '$win32_dispatch_inner'),
]:
    guard()
    p = repo / file
    original = p.read_bytes()
    assert original.count(old.encode()) == 1
    try:
        p.write_bytes(original.replace(old.encode(), new.encode()))
        c = subprocess.run(['node','tools/callback-ownership-census.js'],cwd=repo,capture_output=True,text=True)
        assert c.returncode == 1 and c.stderr.strip() == f'changed producer {file}:{name} (sha256); review its lifetime', c.stderr
        controls.append(dict(file=file,exit=c.returncode,diagnostic=c.stderr.strip(),before=hashlib.sha256(original).hexdigest(),mutated=hashlib.sha256(p.read_bytes()).hexdigest()))
    finally:
        p.write_bytes(original)
        assert hashlib.sha256(p.read_bytes()).hexdigest() == before[file]
    controls[-1]['restored'] = True
(out/'cli-controls.json').write_text(json.dumps(controls,indent=2))
assert seals() == before
run('restored-census', ['node','tools/callback-ownership-census.js'])
run('whitespace', ['git','diff','--check'])
(out/'source-verification.json').write_text(json.dumps(dict(source=rev,files=len(before),allMatchGit=True,restored=True),indent=2))
guard()
