import subprocess,json,pathlib,time,os
root=pathlib.Path(__file__).resolve().parent
cases=[
 ('census',['tools/callback-ownership-census.js'],0),
 ('census-controls',['test/test-callback-ownership-census.js'],0),
 ('process-lifetime',['docs/reviews/hock-canonical-census-20261021.js','--process'],0),
 ('publication',['docs/reviews/hock-canonical-census-20261021.js','--publication'],0),
 ('publication-control',['docs/reviews/hock-canonical-census-20261021.js','--publication','--stale-pointer'],1),
 ('nested-lifetime',['docs/reviews/nested-event-lifetime-repair-20261020.js','--accept'],0),
 ('nested-control',['docs/reviews/nested-event-lifetime-repair-20261020.js','--accept','--remove-lifetime'],1),
 ('named-event',['test/test-named-event-cli-end-to-end.js'],0),
 ('named-duplicate',['test/test-named-event-cli-end-to-end.js','--mutant=duplicate-completion'],1),
 ('named-stale',['test/test-named-event-cli-end-to-end.js','--mutant=stale-continuation'],1),
 ('named-independent',['test/test-named-event-coupled-independent-review.js'],0),
 ('named-forwarding',['test/test-named-event-coupled-independent-review.js','--review-mutant=forwarding'],1),
 ('renderer-input',['test/test-jedi-components-input.js'],0),
 ('renderer-modal',['test/test-renderer-dialog-modal-input.js'],0),
 ('host-window',['test/test-host-window-related.js'],0),
 ('thread-manager',['test/test-thread-manager.js'],0),
 ('thread-zero',['test/test-thread-wait-zero-timeout.js'],0),
]
results=[]
for name,args,expected in cases:
 assert os.statvfs(root).f_bavail*os.statvfs(root).f_frsize>2285895680
 start=time.monotonic()
 p=subprocess.run(['node']+args,cwd=root/'repo',stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60)
 log=p.stdout.decode(errors='replace'); (root/(name+'.final.log')).write_text(log)
 valid=p.returncode==expected and (expected==0 or 'AssertionError' in log)
 results.append(dict(name=name,command=['node']+args,exit=p.returncode,expected=expected,passed=valid,seconds=time.monotonic()-start,log=name+'.final.log'))
 print(name,p.returncode,valid,flush=True)
 (root/'tests.json').write_text(json.dumps(results,indent=2))
assert all(r['passed'] for r in results)
