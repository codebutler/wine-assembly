import os,pathlib,subprocess,json,sys
from run import gate,run,B,R
gate('independent')
out=[]
for mutant,mode,expected in [('two-frames','frames',"expected: 'capture frame limit'"),('four-mib-cumulative','cumulative','expected rejection')]:
 root=B/'tmp'/mutant
 import shutil
 if root.exists():shutil.rmtree(root)
 env=dict(os.environ,INDEPENDENT_MUTANT=mutant)
 cmd=['node','--max-old-space-size=256','--require',str(B/'ops/independent-preload.cjs'),str(R/'test/test-enigma-single-frame-profile.js'),'child',str(root),mode]
 p=subprocess.run(cmd,env=env,capture_output=True,timeout=15)
 assert len(p.stdout)+len(p.stderr)<16384
 (B/('ops/independent-'+mutant+'.stderr')).write_bytes(p.stderr)
 assert p.returncode==1 and b'INDEPENDENT_MUTATION_APPLIED' in p.stderr and expected.encode() in p.stderr,p.stderr
 out.append(dict(mutant=mutant,mode=mode,exit=p.returncode,rejected=True,command=cmd))
 import shutil
 shutil.rmtree(root)
(B/'ops/independent.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out))
