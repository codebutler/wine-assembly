import json,os,pathlib,resource,signal,subprocess,sys,time,shutil
B=pathlib.Path('/tmp/enigma-single-frame-independent-closeout-oct24'); R=B/'repo'
A=json.loads((B/'ops/admission.json').read_text())
def size(p):
 if p.is_file():return p.stat().st_size
 return sum(f.stat().st_size for f in p.rglob('*') if f.is_file()) if p.exists() else 0
def gate(name):
 owned=size(B); ext=sum(size(pathlib.Path(e['path'])) for e in A['external'])
 sql=sum(max(0,size(pathlib.Path(p))-v) for p,v in A['sqliteBaseline'].items())
 projected=owned+ext+sql+24*1024**2+8388608
 free=shutil.disk_usage(B).free
 mem=int(next(l.split()[1] for l in pathlib.Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
 rec=dict(owned=owned,external=ext,positiveSQLite=sql,future=24*1024**2,reserve=8388608,projected=projected,free=free,after=free-(projected-owned)-67108864,memory=mem)
 rec['pass']=projected<=67108864 and rec['after']>=2982150144 and mem>=805306368
 (B/('ops/'+name+'-admission.json')).write_text(json.dumps(rec,indent=2))
 assert rec['pass'],rec
 return rec
def limits():
 resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_FSIZE,(25165824,25165824))
def run(name,cmd):
 gate(name);start=time.monotonic()
 env=dict(os.environ,TMPDIR=str(B/'tmp'),PYTHONDONTWRITEBYTECODE='1');(B/'tmp').mkdir(exist_ok=True)
 with (B/('ops/'+name+'.stdout')).open('wb') as out,(B/('ops/'+name+'.stderr')).open('wb') as err:
  p=subprocess.Popen(cmd,cwd=R,env=env,stdout=out,stderr=err,start_new_session=True,preexec_fn=limits)
  try:p.wait(timeout=60)
  except subprocess.TimeoutExpired:p.send_signal(signal.SIGTERM)
  finally:
   try:os.killpg(p.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:p.wait(timeout=2)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=2)
  assert out.tell()+err.tell()<=131072,'output cap'
 rec=dict(command=cmd,exit=p.returncode,seconds=time.monotonic()-start)
 (B/('ops/'+name+'-result.json')).write_text(json.dumps(rec,indent=2));print(json.dumps(dict(name=name,**rec)),flush=True)
 assert p.returncode==0,rec
if __name__=='__main__':
 for test in ['test-lossless-capture-png.js','test-enigma-lossless-independent.js','test-enigma-terminal-capture-guard.js','test-enigma-single-frame-profile.js','test-enigma-supervisor-exit.py']:
  cmd=['python3','test/'+test] if test.endswith('.py') else ['node','--max-old-space-size=256','test/'+test]
  run(sys.argv[1]+'-'+test.split('.')[0],cmd)
