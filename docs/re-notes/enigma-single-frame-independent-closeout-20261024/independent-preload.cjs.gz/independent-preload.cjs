'use strict';
const Module=require('node:module'),assert=require('node:assert/strict');
const compile=Module.prototype._compile;
Module.prototype._compile=function(source,file){
 if(file.endsWith('/capture.cjs')){
  const [from,to]=process.env.INDEPENDENT_MUTANT==='two-frames'
   ? ["assert(++frames<=1,'capture frame limit')","assert(++frames<=2,'capture frame limit')"]
   : ["assert(total<=2097152,'capture cumulative byte limit')","assert(total<=4194304,'capture cumulative byte limit')"];
  assert.equal(source.split(from).length,2,'final deployed writer anchor');
  source=source.replace(from,to);
  process.stderr.write('INDEPENDENT_MUTATION_APPLIED\n');
 }
 return compile.call(this,source,file);
};
