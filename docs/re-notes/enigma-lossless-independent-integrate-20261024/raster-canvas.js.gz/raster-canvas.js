// A small RGBA raster canvas for headless runs.
//
// WHY: the CLI used skia-canvas, a native dependency that leaks roughly 320
// bytes per draw call and cannot be made to give it back. It was adopted
// (259623f) because node-canvas had no Path2D and the CLI's clip path was a
// no-op stub, so headless renders silently disagreed with the browser. That
// reason has since evaporated: WAT owns GDI rasterization and hands JavaScript
// finished pixels via gdi_surface_upload, and clipping arrives as rectangle
// bands, never as paths. What is left for the presenter to do is blit and
// clip rectangles -- measured across notepad/calc/mspaint, the screen canvas
// uses exactly six members, and back-canvases see no 2D calls at all.
//
// So this implements that measured surface and nothing more. Every clip in the
// renderer is built from ctx.rect() alone, so clipping here is an intersection
// of rectangles rather than a path engine. If something ever needs real paths
// or text, it belongs in the browser renderer, not here.
//
// The browser keeps using the real canvas; this is CLI/test only.

const { PNG } = require('pngjs');

function clampByte(v) { return v < 0 ? 0 : v > 255 ? 255 : v | 0; }

// Accepts the forms the renderer actually produces: #rgb, #rrggbb, #rrggbbaa,
// rgb(r,g,b) and rgba(r,g,b,a). Anything else paints opaque black rather than
// throwing, matching canvas's habit of ignoring nonsense.
function parseColor(style) {
  if (typeof style !== 'string') return [0, 0, 0, 255];
  const s = style.trim();
  if (s[0] === '#') {
    const h = s.slice(1);
    if (h.length === 3) {
      return [parseInt(h[0] + h[0], 16), parseInt(h[1] + h[1], 16), parseInt(h[2] + h[2], 16), 255];
    }
    if (h.length === 6 || h.length === 8) {
      return [
        parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16),
        h.length === 8 ? parseInt(h.slice(6, 8), 16) : 255,
      ];
    }
    return [0, 0, 0, 255];
  }
  const m = s.match(/^rgba?\(([^)]+)\)$/i);
  if (m) {
    const p = m[1].split(',').map(x => parseFloat(x));
    return [clampByte(p[0]), clampByte(p[1]), clampByte(p[2]),
      p.length > 3 ? clampByte(p[3] * 255) : 255];
  }
  return [0, 0, 0, 255];
}

function intersect(a, b) {
  const x = Math.max(a.x, b.x);
  const y = Math.max(a.y, b.y);
  const r = Math.min(a.x + a.w, b.x + b.w);
  const btm = Math.min(a.y + a.h, b.y + b.h);
  return { x, y, w: Math.max(0, r - x), h: Math.max(0, btm - y) };
}

class ImageDataPoly {
  constructor(dataOrW, wOrH, h) {
    if (typeof dataOrW === 'number') {
      this.width = dataOrW | 0;
      this.height = wOrH | 0;
      this.data = new Uint8ClampedArray(this.width * this.height * 4);
    } else {
      this.data = dataOrW;
      this.width = wOrH | 0;
      this.height = h | 0;
    }
  }
}

class RasterContext {
  constructor(canvas) {
    this.canvas = canvas;
    this.fillStyle = '#000000';
    this.strokeStyle = '#000000';
    this.lineWidth = 1;
    this.globalAlpha = 1;
    this.imageSmoothingEnabled = false;
    this.lineDashOffset = 0;
    this.globalCompositeOperation = 'source-over';
    this._lineDash = 0;
    this._clip = { x: 0, y: 0, w: canvas.width, h: canvas.height };
    this._stack = [];
    this._path = [];
  }

  // A resize resets context state, clip included.
  _reset() {
    this._clip = { x: 0, y: 0, w: this.canvas.width, h: this.canvas.height };
    this._stack = [];
    this._path = [];
  }

  save() {
    this._stack.push({
      fillStyle: this.fillStyle, strokeStyle: this.strokeStyle,
      lineWidth: this.lineWidth, globalAlpha: this.globalAlpha,
      imageSmoothingEnabled: this.imageSmoothingEnabled,
      clip: this._clip,
    });
  }

  restore() {
    const s = this._stack.pop();
    if (!s) return;
    this.fillStyle = s.fillStyle;
    this.strokeStyle = s.strokeStyle;
    this.lineWidth = s.lineWidth;
    this.globalAlpha = s.globalAlpha;
    this.imageSmoothingEnabled = s.imageSmoothingEnabled;
    this._clip = s.clip;
  }

  beginPath() { this._path = []; }
  moveTo() {}
  lineTo() {}
  closePath() {}
  rect(x, y, w, h) { this._path.push({ x: Math.round(x), y: Math.round(y), w: Math.round(w), h: Math.round(h) }); }

  // Rectangles only. The renderer builds every clip from rect() -- a plain
  // client rect, or the band list of a shaped window -- so the clip is the
  // union of the pending rects, intersected with the clip already in force.
  clip() {
    if (!this._path.length) return;
    let union = null;
    for (const r of this._path) {
      if (r.w <= 0 || r.h <= 0) continue;
      union = union ? {
        x: Math.min(union.x, r.x), y: Math.min(union.y, r.y),
        w: Math.max(union.x + union.w, r.x + r.w) - Math.min(union.x, r.x),
        h: Math.max(union.y + union.h, r.y + r.h) - Math.min(union.y, r.y),
      } : { ...r };
    }
    if (union) this._clip = intersect(this._clip, union);
    this._path = [];
  }

  _blend(i, r, g, b, a) {
    const d = this.canvas._data;
    if (a >= 255) { d[i] = r; d[i + 1] = g; d[i + 2] = b; d[i + 3] = 255; return; }
    if (a <= 0) return;
    const sa = a / 255;
    const da = d[i + 3] / 255;
    const outA = sa + da * (1 - sa);
    if (outA <= 0) { d[i] = d[i + 1] = d[i + 2] = d[i + 3] = 0; return; }
    d[i] = (r * sa + d[i] * da * (1 - sa)) / outA;
    d[i + 1] = (g * sa + d[i + 1] * da * (1 - sa)) / outA;
    d[i + 2] = (b * sa + d[i + 2] * da * (1 - sa)) / outA;
    d[i + 3] = outA * 255;
  }

  _span(x, y, w, h) {
    return intersect({ x: Math.round(x), y: Math.round(y), w: Math.round(w), h: Math.round(h) }, this._clip);
  }

  fillRect(x, y, w, h) {
    const [r, g, b, a0] = parseColor(this.fillStyle);
    const a = clampByte(a0 * this.globalAlpha);
    const rect = this._span(x, y, w, h);
    const cw = this.canvas.width;
    // The renderer draws its drag/marquee rectangle by filling white in
    // 'difference' mode, which is how a rubber band stays visible over any
    // background. Ignoring the composite mode painted a solid white block
    // instead -- and, being merely wrong rather than fatal, it would not have
    // announced itself.
    const diff = this.globalCompositeOperation === 'difference';
    const d = this.canvas._data;
    for (let yy = rect.y; yy < rect.y + rect.h; yy++) {
      let i = (yy * cw + rect.x) * 4;
      for (let xx = 0; xx < rect.w; xx++, i += 4) {
        if (diff) {
          d[i] = Math.abs(d[i] - r);
          d[i + 1] = Math.abs(d[i + 1] - g);
          d[i + 2] = Math.abs(d[i + 2] - b);
          if (!d[i + 3]) d[i + 3] = a;
        } else {
          this._blend(i, r, g, b, a);
        }
      }
    }
  }

  clearRect(x, y, w, h) {
    const rect = this._span(x, y, w, h);
    const d = this.canvas._data;
    const cw = this.canvas.width;
    for (let yy = rect.y; yy < rect.y + rect.h; yy++) {
      d.fill(0, (yy * cw + rect.x) * 4, (yy * cw + rect.x + rect.w) * 4);
    }
  }

  // The resize outline is a dashed rectangle, so this has to be real rather
  // than a no-op: the renderer calls it without a capability check, and a
  // missing method throws mid-repaint (which is how the window-resize tests
  // failed -- the drag threw before the window was ever resized).
  setLineDash(segments) {
    this._lineDash = Array.isArray(segments) && segments.length ? Math.max(1, segments[0] | 0) : 0;
  }

  getLineDash() { return this._lineDash ? [this._lineDash, this._lineDash] : []; }

  // Outline only; the renderer uses this for focus, frame and resize rects.
  strokeRect(x, y, w, h) {
    const saved = this.fillStyle;
    this.fillStyle = this.strokeStyle;
    const lw = Math.max(1, this.lineWidth | 0);
    const dash = this._lineDash | 0;
    if (!dash) {
      this.fillRect(x, y, w, lw);
      this.fillRect(x, y + h - lw, w, lw);
      this.fillRect(x, y, lw, h);
      this.fillRect(x + w - lw, y, lw, h);
    } else {
      for (let i = 0; i < w; i += dash * 2) {
        const run = Math.min(dash, w - i);
        this.fillRect(x + i, y, run, lw);
        this.fillRect(x + i, y + h - lw, run, lw);
      }
      for (let i = 0; i < h; i += dash * 2) {
        const run = Math.min(dash, h - i);
        this.fillRect(x, y + i, lw, run);
        this.fillRect(x + w - lw, y + i, lw, run);
      }
    }
    this.fillStyle = saved;
  }

  createImageData(w, h) { return new ImageDataPoly(w, h); }

  getImageData(x, y, w, h) {
    const out = new ImageDataPoly(w | 0, h | 0);
    const src = this.canvas._data;
    const cw = this.canvas.width;
    const ch = this.canvas.height;
    for (let yy = 0; yy < out.height; yy++) {
      const sy = (y | 0) + yy;
      if (sy < 0 || sy >= ch) continue;
      for (let xx = 0; xx < out.width; xx++) {
        const sx = (x | 0) + xx;
        if (sx < 0 || sx >= cw) continue;
        const si = (sy * cw + sx) * 4;
        const di = (yy * out.width + xx) * 4;
        out.data[di] = src[si]; out.data[di + 1] = src[si + 1];
        out.data[di + 2] = src[si + 2]; out.data[di + 3] = src[si + 3];
      }
    }
    return out;
  }

  // Canvas semantics: putImageData ignores both the clip and globalAlpha, and
  // replaces destination pixels outright rather than compositing.
  // The 7-argument form writes only the dirty rect, in source coordinates,
  // to dx+dirtyX / dy+dirtyY. A DirectDraw app that owns a window rather than
  // the display presents through it: only the part of the primary under its
  // client area may be written, or the caption and menu bar next to it are
  // overwritten by the frame.
  putImageData(img, dx, dy, dirtyX, dirtyY, dirtyW, dirtyH) {
    const d = this.canvas._data;
    const cw = this.canvas.width;
    const ch = this.canvas.height;
    let x0 = 0;
    let y0 = 0;
    let x1 = img.width;
    let y1 = img.height;
    if (dirtyW !== undefined && dirtyH !== undefined) {
      x0 = Math.max(0, Math.min(img.width, dirtyX | 0));
      y0 = Math.max(0, Math.min(img.height, dirtyY | 0));
      x1 = Math.max(x0, Math.min(img.width, (dirtyX | 0) + (dirtyW | 0)));
      y1 = Math.max(y0, Math.min(img.height, (dirtyY | 0) + (dirtyH | 0)));
    }
    for (let yy = y0; yy < y1; yy++) {
      const ty = (dy | 0) + yy;
      if (ty < 0 || ty >= ch) continue;
      for (let xx = x0; xx < x1; xx++) {
        const tx = (dx | 0) + xx;
        if (tx < 0 || tx >= cw) continue;
        const si = (yy * img.width + xx) * 4;
        const di = (ty * cw + tx) * 4;
        d[di] = img.data[si]; d[di + 1] = img.data[si + 1];
        d[di + 2] = img.data[si + 2]; d[di + 3] = img.data[si + 3];
      }
    }
  }

  drawImage(src, ...a) {
    const sw0 = src.width | 0;
    const sh0 = src.height | 0;
    if (!sw0 || !sh0) return;
    let sx = 0, sy = 0, sw = sw0, sh = sh0, dx = 0, dy = 0, dw = sw0, dh = sh0;
    if (a.length === 2) { [dx, dy] = a; }
    else if (a.length === 4) { [dx, dy, dw, dh] = a; }
    else if (a.length === 8) { [sx, sy, sw, sh, dx, dy, dw, dh] = a; }
    else return;

    const sdata = src._data || (src.data instanceof Uint8ClampedArray ? src.data : null);
    if (!sdata) return;

    dx = Math.round(dx); dy = Math.round(dy);
    dw = Math.round(dw); dh = Math.round(dh);
    if (dw <= 0 || dh <= 0 || sw <= 0 || sh <= 0) return;

    const rect = intersect({ x: dx, y: dy, w: dw, h: dh }, this._clip);
    if (rect.w <= 0 || rect.h <= 0) return;

    const cw = this.canvas.width;
    const alpha = this.globalAlpha;
    // Nearest neighbour. Win98 pixels are not meant to be resampled, and the
    // renderer sets imageSmoothingEnabled=false everywhere for that reason.
    for (let yy = rect.y; yy < rect.y + rect.h; yy++) {
      const v = sy + Math.floor(((yy - dy) * sh) / dh);
      if (v < 0 || v >= sh0) continue;
      for (let xx = rect.x; xx < rect.x + rect.w; xx++) {
        const u = sx + Math.floor(((xx - dx) * sw) / dw);
        if (u < 0 || u >= sw0) continue;
        const si = (v * sw0 + u) * 4;
        const a4 = clampByte(sdata[si + 3] * alpha);
        if (!a4) continue;
        this._blend((yy * cw + xx) * 4, sdata[si], sdata[si + 1], sdata[si + 2], a4);
      }
    }
  }

  // Present only so callers that set them do not crash; nothing headless reads
  // back text metrics -- WAT measures and rasterizes all text itself.
  measureText(text) { return { width: (String(text).length * 8) }; }
  fillText() {}
  strokeText() {}
  setTransform() {}
  translate() {}
  scale() {}
  fill() {}
  stroke() {}
}

class RasterCanvas {
  constructor(w, h) {
    this._w = Math.max(1, w | 0);
    this._h = Math.max(1, h | 0);
    this._pix = new Uint8ClampedArray(this._w * this._h * 4);
    this._ctx = null;
    this._gl = null;        // headless WebGL context, if one was requested
    this._glDirty = false;  // GL has presented a frame these pixels do not have
  }

  // `_data` is the pixel buffer every reader in this file and in the
  // compositor reaches for (drawImage takes `src._data`, toBufferSync writes
  // it out). When a headless GL context is attached, the real pixels live in
  // the driver's drawing buffer instead, so the read has to pull them back
  // first -- as a getter, because making every one of those call sites
  // GL-aware is how you end up with one that isn't and a black frame nobody
  // can explain.
  //
  // The sync is gated on _glDirty, set by present(). That is not an
  // optimisation, it is the contract: readPixels mid-frame would hand the
  // compositor a half-drawn scene, and "the last presented frame" is exactly
  // what SwapBuffers already promises everywhere else in this codebase.
  get _data() {
    if (this._glDirty) this._syncFromGl();
    return this._pix;
  }

  set _data(v) { this._pix = v; }

  _syncFromGl() {
    this._glDirty = false;
    if (!this._gl) return;
    try {
      require('./headless-gl').readPixelsInto(this._gl, this._w, this._h, this._pix);
    } catch (_) { /* leave the previous frame rather than a torn one */ }
  }

  // Called by the GPU backend's present()/SwapBuffers. See _data.
  markGlPresented() { this._glDirty = true; }

  releaseWebGLContext() {
    if (!this._gl) return;
    require('./headless-gl').destroyContext(this._gl);
    this._gl = null;
    this._glDirty = false;
  }

  // Assigning width or height reallocates and clears the surface, and resets
  // the context -- the same semantics a real canvas has, including when the
  // value does not change. Screen resizes go through exactly this (test/run.js
  // sets renderer.canvas.width), and treating these as plain data properties
  // left the pixel buffer at its original size: the window-resize tests failed
  // because the surface never grew.
  get width() { return this._w; }
  set width(v) { this._resize(v, this._h); }
  get height() { return this._h; }
  set height(v) { this._resize(this._w, v); }

  _resize(w, h) {
    w = Math.max(1, w | 0);
    h = Math.max(1, h | 0);
    if (w === this._w && h === this._h) {
      this._pix.fill(0);
    } else {
      this._w = w;
      this._h = h;
      this._pix = new Uint8ClampedArray(w * h * 4);
    }
    if (this._ctx) this._ctx._reset();
    if (this._gl) {
      // A drawing buffer left at the old size does not fail, it renders at the
      // wrong scale -- which reads downstream as a compositor bug. If the build
      // cannot resize, drop the context so the next getContext() makes a
      // correctly sized one.
      const hgl = require('./headless-gl');
      if (!hgl.resizeContext(this._gl, w, h)) {
        hgl.destroyContext(this._gl);
        this._gl = null;
      }
      this._glDirty = false;
    }
  }

  getContext(type, opts) {
    // Headless WebGL, so the OpenGL guests are not browser-only. Optional
    // native deps: absent, this returns null exactly as it always did, and the
    // caller takes its no-3D-hardware path. See lib/headless-gl.js.
    if (type === 'webgl' || type === 'experimental-webgl') {
      if (this._gl) return this._gl;
      this._gl = require('./headless-gl').createContext(this._w, this._h, opts);
      return this._gl;
    }
    if (type && type !== '2d') return null;
    if (!this._ctx) this._ctx = new RasterContext(this);
    return this._ctx;
  }

  toBufferSync() {
    const png = new PNG({ width: this.width, height: this.height });
    png.data = Buffer.from(this._data.buffer, this._data.byteOffset, this._data.length);
    return PNG.sync.write(png);
  }

  // skia-canvas types toBuffer() as async; callers here have always used it
  // synchronously, so keep it synchronous and let toBufferSync be the honest name.
  toBuffer() { return this.toBufferSync(); }

  // The renderer's browser-desktop path hands the wallpaper to the page as a
  // data: URL. Without this the whole branch was unreachable headlessly and
  // silently skipped, so nothing tested it. PNG is the only format anyone
  // here asks for.
  toDataURL(type) {
    if (type && type !== 'image/png') return `data:${type};base64,`;
    return `data:image/png;base64,${this.toBufferSync().toString('base64')}`;
  }
}

function createCanvas(w, h) { return new RasterCanvas(w, h); }

async function loadImage(src) {
  const fs = require('fs');
  const buf = Buffer.isBuffer(src) ? src : fs.readFileSync(src);
  const png = PNG.sync.read(buf);
  const img = new RasterCanvas(png.width, png.height);
  img._data.set(new Uint8ClampedArray(png.data.buffer, png.data.byteOffset, png.data.length));
  return img;
}

function registerFont() { /* WAT owns fonts; nothing to register headless. */ }

module.exports = {
  createCanvas, loadImage, registerFont,
  Canvas: RasterCanvas, Image: RasterCanvas, ImageData: ImageDataPoly,
};
